<!DOCTYPE html>
<html lang="en">

<head>
	<title>Enhancements 1| TheBest</title>
	<meta charset="utf-8" />
	<meta name="Author" content="TheBest" />
	<meta name="Description" content="rent,best,house" />
	<meta name="Keywords" content="rent,best,house" />
	<link rel="stylesheet" type="text/css" href="styles/style.css" />
	<script src="script/dropdown.js"></script>
</head>

<body>	
<?php include 'include/header.php';?>
	
	<article class="enhancementsA">
		<br />
		
		<h1 class="enhancements_h1">Enhancement 1: HTML & CSS</h1>
		
		<br />
		<br />
		
		<section class="enhancementsS">
		<h2 class="enhancements_h2">Embedding external content</h2>
		<p class="en_con">Google Maps are embedded into all product webpages</p>
		<p class="en_con">&lt;iframe&gt;&lt;/iframe&gt; is used</p>
		<p class="en_con">These pages below has the enhancements:</p>
		
		<ul class="enhancementsL">
			<li><a href="product1.php">product1.php</a></li>
			<li><a href="product2.php">product2.php</a></li>
			<li><a href="product3.php">product3.php</a></li>
			<li><a href="product4.php">product4.php</a></li>
			<li><a href="product5.php">product5.php</a></li>
			
			<li><a href="product6.php">product6.php</a></li>
			<li><a href="product7.php">product7.php</a></li>
			<li><a href="product8.php">product8.php</a></li>
			<li><a href="product9.php">product9.php</a></li>
			<li><a href="product10.php">product10.php</a></li>
			
			<li><a href="product11.php">product11.php</a></li>
			<li><a href="product12.php">product12.php</a></li>
			<li><a href="product13.php">product13.php</a></li>
			<li><a href="product14.php">product14.php</a></li>
			<li><a href="product15.php">product15.php</a></li>
			
			<li><a href="product16.php">product16.php</a></li>
			<li><a href="product17.php">product17.php</a></li>
			<li><a href="product18.php">product18.php</a></li>
			<li><a href="product19.php">product19.php</a></li>
			<li><a href="product20.php">product20.php</a></li>
		</ul>
		</section>
		
		<section class="enhancementsS">
		<h2 class="enhancements_h2">Transition</h2>
		<p class="en_con">CSS transitions allows you to change property values smoothly (from one value to another), over a given duration.</p>
		<p class="en_con">To create a transition effect, two things must be specified, the CSS property that wanted to add an effect to and the duration of the effect</p>
		<p class="en_con">transition: Xs is used where X is the duration of the effect</p>
		<p class="en_con">for example, refer to:</p>
		<p class="en_con"><a href="https://www.w3schools.com/css/css3_transitions.asp">https://www.w3schools.com/css/css3_transitions.asp</a></p>
		
		<p class="en_con">These pages below has the enhancements:</p>
		
		<ul class="enhancementsL">			
			<li><a href="about0.php">about0.php</a></li>
			<li><a href="about1.php">about1.php</a></li>
			<li><a href="about2.php">about2.php</a></li>
			<li><a href="about3.php">about3.php</a></li>
			<li><a href="about4.php">about4.php</a></li>
			
			<li><a href="disclaimer.php">disclaimer.php</a></li>
			<li><a href="enhancements.php">enhancements.php</a></li>
			<li><a href="enquiry.php">enquiry.php</a></li>
			<li><a href="index.php">index.php</a></li>
			<li><a href="pahang.php">pahang.php</a></li>
			
			<li><a href="product1.php">product1.php</a></li>
			<li><a href="product2.php">product2.php</a></li>
			<li><a href="product3.php">product3.php</a></li>
			<li><a href="product4.php">product4.php</a></li>
			<li><a href="product5.php">product5.php</a></li>
			
			<li><a href="product6.php">product6.php</a></li>
			<li><a href="product7.php">product7.php</a></li>
			<li><a href="product8.php">product8.php</a></li>
			<li><a href="product9.php">product9.php</a></li>
			<li><a href="product10.php">product10.php</a></li>
			
			<li><a href="product11.php">product11.php</a></li>
			<li><a href="product12.php">product12.php</a></li>
			<li><a href="product13.php">product13.php</a></li>
			<li><a href="product14.php">product14.php</a></li>
			<li><a href="product15.php">product15.php</a></li>
			
			<li><a href="product16.php">product16.php</a></li>
			<li><a href="product17.php">product17.php</a></li>
			<li><a href="product18.php">product18.php</a></li>
			<li><a href="product19.php">product19.php</a></li>
			<li><a href="product20.php">product20.php</a></li>
			
			<li><a href="sabah.php">sabah.php</a></li>
			<li><a href="sarawak.php">sarawak.php</a></li>
			<li><a href="selangor.php">selangor.php</a></li>
			
			
			

		</ul>
		</section>
		
	</article>
	
<?php include 'include/footer.php';?>

</body>

</html>