<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Home | TheBest</title>
	<meta name="viewport" content="initial-scale=1, width=device-width, maximum-scale=1, minimum-scale=1, user-scalable=no">
	<link rel="stylesheet" type="text/css" href="styles/style.css">
	
	<style>
	.mySlides {
		display: none;
	}

	.mySlides img{
		width:90%;
		margin-left:5%;
	}

	.slideshow-container{
		position:absolute;
		top:57%;
		left:50%;
		width: 55%;
		transform: translateX(-50%) translateY(-50%);
	}

	.prev, .next{
		cursor: pointer;
		position: absolute;
		top: 45%;
		width: auto;
		margin: auto;
		padding: 10px;
		color: black;
		font-weight: bold;
		font-size: 2vw;
		transition: 0.6s ease;
		border-radius: 0 3px 3px 0;
	}

	.next{
		right: 0;
		border-radius: 3px 0 0 3px;
	}

	.prev:hover, .next:hover{
		color: white;
		background-color: black;
	}
	</style>
</head>

<body class="indexbody">
<div class="wrapper">
	<?php include 'include/header.php';?>
	<main>
		<section class="section">
			<div class="s1">
				<img src="images/Plogo.png" alt="Logo" />
				<h1>"All we rent are the best"</h1>
			</div>
		</section>

		<section class="section">
			<div class="s2">
				<h1>What is TheBestRental?</h1>
				<h2>We're Malaysia’s Best Property Rental Company</h2>
				
				<p>
				We are your local premier property management company. Since 1989 we have offered full-service leasing & property management in Kansas City.
				
				<br />
				<br />
				
				We handle everything including finding and screening the tenants, coordinating maintenance, doing periodic inspections and preparing detailed financial reports for our clients. Our systematic processes reduce your vacancy, help to keep tenants longer and get you the highest rent possible. We make your investment work for you, so you can focus on other things!
				
				<br />
				<br />
				
				Our comprehensive Investor Services are absolutely FREE to our clients. We have a custom program to help you find the best rental properties and grow your portfolio. Scroll down for more details!
				</p>
			</div>
		</section>

		<section class="section">
		
			<div class="s3">
				
				<h1>Reasons To Choose TheBestRental</h1>
				
				<table class="indexTable">
				<tr>
					<th><img src="images/money.png" alt="money icon" /></th>
					<th><img src="images/privacy.png" alt="privacy icon" /></th>
					<th><img src="images/customerService.png" alt="customerservice icon" /></th>
				</tr>
				
				<tr>
					<th>Price confidence</th>
					<th>Privacy Matters</th>
					<th>24/7 Customer service</th>
				</tr>
				
				<tr>
					<td>The team only bring you the best prices. If you don’t believe you can compare the price from our website to the others.</td>
					<td>TheBestRental doesn't share your contact details, so you won't be hassled by unwanted calls. Once you've received your offers, you can call or message the renter at your convenience.</td>
					<td>Having any issue with our website during late night? Just give us a call and our assistance will help you anytime anywhere.</td>
				</tr>
				</table>
			</div>
			
		</section>
		
		<section class="section">
			<div class="s5">
				<h1>"Slideshow"</h1>
				
				<div class="slideshow-container">
					<div class="mySlides fade">
						<img src="https://pmcvariety.files.wordpress.com/2018/07/bradybunchhouse_sc11.jpg?w=1000&h=563&crop=1">
					</div>
					
					<div class="mySlides fade">
						<img src="http://www.whitehouse51.com/pic/hbz.h-cdn.co/assets/15/34/1600x800/landscape-1440287556-la-fi-four-seasons-condos-20150821-1940x1212.jpg">
					</div>
				
					<div class="mySlides fade">
						<img src="https://wallpaper.wiki/wp-content/uploads/2017/04/wallpaper.wiki-Cool-Beach-House-1920x1200-PIC-WPB0015530.jpg">
					</div>
					
					<div class="mySlides fade">
						<img src="https://images.adsttc.com/media/images/58bc/4293/e58e/cecd/d000/016d/newsletter/FEATURED_IMAGE.jpg?1488732815">
					</div>
					
					<div class="mySlides fade">
						<img src="https://bizimages.withfloats.com/actual/5b5458718c79b9066438d351.jpg">
					</div>
					
					<div class="mySlides fade">
						<img src="https://wallpaper.wiki/wp-content/uploads/2017/04/wallpaper.wiki-Beach-House-Background-HD-PIC-WPB0015524.jpg">
					</div>
					
					<div class="mySlides fade">
						<img src="https://dkc9trqgco1sw.cloudfront.net/s3fs-public/editorial/DistinctIdentity-1.jpg">
					</div>
					
					<a class="prev" onclick="plusSlides(-1)">&#10094;</a>
					<a class="next" onclick="plusSlides(1)">&#10095;</a>
					<script src="script/Slideshowscript.js"></script>
				</div>
			</div>
		</section>
		
		<section class="section">
			<div class="s4">
			<h1>Get In Touch With Us Now</h1>

			<table class="icontable">
				<tr>
					<td><a href="https://www.facebook.com/"><img id="icon" class="index_icon" src="images/fb.png" alt="facebook" ></a></td>
					<td><a href="https://plus.google.com/discover"><img class="index_icon" src="images/googleplus.png" alt="google"></a></td>
					<td><a href="https://twitter.com/login?lang=en"><img class="index_icon" id="twitter" src="images/twitter.png" alt="twitter"></a></td>
					<td><a href="https://www.instagram.com/accounts/login/"><img class="index_icon" src="images/insta.png" alt="instagram"></a></td>
				</tr>
			</table>
			
			<h2>Still have any question?</h2>
			<p>Kindly leave us an email at <a href="mailto:thebest999899@gmail.com">thebest999899@gmail.com</a></p>
			</div>
			
		</section>
	
	</main>
</div>

<nav class="main-menu">
	<ul class="pagination">
		<li><a></a></li>
		<li><a></a></li>
		<li><a></a></li>
		<li><a></a></li>
		<li><a></a></li>
	</ul>
</nav>

<?php include 'include/footer.php';?>

<script src="script/skrllr.js" charset="utf-8"></script>

<script>
    document.addEventListener('DOMContentLoaded', (event) => {
      const skrllr = new Skrllr('main', {
        transitionTime: 1000,
        easing: 'cubic-bezier(0.77, 0, 0.175, 1)',
        updateURL: true,
        menu: document.querySelector('.pagination'),
        beforeTransition: (index, nextIndex, next) => before(index, nextIndex, next),
        afterTransition: (index, nextIndex, next) => after(index, nextIndex, next),
      })

      // setTimeout(() => skrllr.goTo(1), 2000)

      function before (index, nextIndex, next) {
        console.log('Before transition');
      }

      function after (index, nextIndex, next) {
        console.log('After transition');
        console.log(index);
        console.log(nextIndex);
        console.log(next);
      }
    }, false)
</script>

</body>
</html>