<!DOCTYPE html>
<html lang="en">

<head>
	<title>Cozy Family Suite | TheBest</title>
	<meta charset="utf-8" />
	<meta name="Author" content="TheBest" />
	<meta name="Description" content="rent,best,house" />
	<meta name="Keywords" content="rent,best,house" />
	<link rel="stylesheet" type="text/css" href="styles/style.css" />
	<script src="script/script.js"></script>
	<script src="script/dropdown.js"></script>
</head>

<body>	
<?php include 'include/header.php';?>
	
	<article class="productA">
		<br />
		
		<!--Slideshow implement later-->
		<img class="product_img" src="https://a0.muscache.com/im/pictures/20428719/6b1f87aa_original.jpg?aki_policy=x_large" alt="Cozy Family Suite" />
		
		<!--Source https://www.airbnb.com/rooms/1275216?location=Selangor%20Malaysia&adults=1&children=0&infants=0&s=yig0o5oU-->
		
		<h1 class="product_h1" id="pTitle">Cozy Family Suite</h1>
		
		<aside>
			<form>
				<table>
					<tr class="trow1">
						<th colspan="2">
							RM 169 per night<br/><hr class="line1"/>
						</th>
					</tr>
					
					<tr class="trow2">
						<th colspan="2">
							Date &amp; Guest selection<br/><hr class="line2"/>
						</th>
					</tr>
					
					<tr class="trow3">
						<td>
							Check in
						</td>
						<td>
							<input class="form-ctrl" type="date" name="date"/>
						</td>
					</tr>
					
					<tr class="trow4">
						<td>
							Check out
						</td>
						<td>
							<input class="form-ctrl" type="date" name="date"/>
						</td>
					</tr>
					
					<tr class="trow5">
						<td>
							Guest
						</td>
						<td>
							<select class="form-ctrl" name="guest" size="1">
								<option value="1" selected="selected">1 Guest</option>
								<option value="2">2 Guests</option>
								<option value="3">3 Guests</option>
								<option value="4">4 Guests</option>
								<option value="5">5 Guests</option>
								<option value="6">6 Guests</option>
								<option value="7">7 Guests</option>
								<option value="8">8 Guests</option>
								<option value="9">9 Guests</option>
								<option value="10">10 Guests</option>
							</select>
							
						</td>
					</tr>
					
					<tr class="trow6">
						<td colspan="2">
							<hr class="line3"/><a href="enquiry.php" onclick="nameStore()" class="booknow">Book Now</a>
						</td>
					</tr>
				</table>
			</form>
		</aside>
	
		<table class="specification">
			<tr>
				<td><img class="guest" src="images/icon-guest.svg" alt="Guests bullet"/>5 guests</td>
				<td><img class="bedroom" src="images/bath.png" alt="Bedroom bullet"/>1 bedrooms</td>
				<td><img class="bed" src="images/bed.png" alt="Bed bullet"/>3 beds</td>
				<td><img class="bath" src="images/bath.png" alt="Bathroom bullet"/>1 bathrooms</td>
			</tr>
		</table>
		
		<p class="product_content">Our home is perch over on the high floor with a good view of the building's courtyard gardens. You can also lounge at the SkyLounge swimming Pool.</p>
		
		<h2 class="product_h2">The space</h2>
		<p class="product_content">THIS IS A COZY AND WARM SUITE!!!</p>
		<p class="product_content">This is a cozy suite designed by your local host, Greg. You can also lounge at the SkyLounge swimming Pool @37th Floor with the ALL IN ONE view of KL Twin Towers, Golden Triangle and KL Towers.</p>
		
		<span class="listH">About the Residence</span>
		
		<ul class="product_content space">
			<li>You will have the entire suite to yourself!</li>
			<li>It’s approximately 500sqf (60sqm)</li>
			<li>Fridge </li>
			<li>One Queen sized bed with Luxury Hotel Collection 700 thread count sheet, air conditioned, Clothes closet.</li>
			<li>Cozy Queen Size Sofa Bed and Dining Table</li>
			<li> Private bathroom with RainForest hot shower</li>
			<li>TV</li>
			<li>Coffee and Tea making facilities</li>
			<li>Complimentary WIFI Internet in suite and WIFI at Common Areas.</li>
			<li>Fully equipped kitchen with microwave-oven and utensils (only light cooking is allowed)</li>
		</ul>
		
		<p class="product_content">Common facilities consists of 37th Floor SkyLounge and Infinity Pool, gym room fully equipped with commercial grade equipment, steam Rooms, Squash Courts, reading room, Steam Room , 2 swimming pools and well planned and maintained landscape.
		There is a convenience store, laundry service, within the apartment complex itself.</p>
		
		<h2 class="product_h2">Guest access</h2>		
		<p class="product_content">You will have the entire apartment to yourself!</p>
		
		<h2 class="product_h2">Interaction with guests</h2>
		<p class="product_content">You may check in directly using the instructions provided. I am available to assist you anytime during check in by calling my phone numb (Phone number hidden by Airbnb).</p>
		
		<h2 class="product_h2">Amenities</h2>
		<ul class="amenities">
			<li>Wifi</li>
			<li>Kitchen</li>
			<li>Elevator</li>
			<li>Dryer</li>
			<li>Iron</li>
			<li>Hair dryer</li>
		</ul>
		
		<h2 class="product_h2">Location</h2>
		
		<span class="listH">Places nearby</span>
		
		<ul class="product_content location">
			<li>It is flanked by two major rail transit lines and within Walking Distance and by transit, you can reach the City Center in 3-4 stops only</li>
			<li>1. Sri Petaling Line LRT metro - 4~6 mins</li>
			<li>2. KTM Komuter 2~3 mins</li>
		</ul>
		
		<div class="mapouter">
			<div class="gmap_canvas">
				<iframe id="gmap_canvas" src="https://maps.google.com/maps?q=%20Kuala%20Lumpur&t=&z=13&ie=UTF8&iwloc=&output=embed"></iframe>
			</div>
		</div>
		
	</article>
	
	<?php include 'include/footer.php';?>

</body>

</html>