<!DOCTYPE html>
<html lang="en">

<head>
	<title>Imago Luxurious Room | TheBest</title>
	<meta charset="utf-8" />
	<meta name="Author" content="TheBest" />
	<meta name="Description" content="rent,best,house" />
	<meta name="Keywords" content="rent,best,house" />
	<link rel="stylesheet" type="text/css" href="styles/style.css" />
	<script src="script/script.js"></script>
	<script src="script/dropdown.js"></script>
</head>

<body>	
<?php include 'include/header.php';?>
	
	<article class="productA">
		<br />
		
		<!--Slideshow implement later-->
		<img class="product_img" src="https://a0.muscache.com/im/pictures/8b9816d7-84ac-485b-a832-60a3c77f3a40.jpg?aki_policy=x_large" alt="Imago Room Sea View" />
		
		<!--Source https://www.airbnb.com/rooms/17988427?location=Sabah%20Malaysia&adults=2&children=0&infants=0&home_collection=1&s=8XE1xCE1 -->
		
		<h1 class="product_h1" id="pTitle">Imago Luxurious Room</h1>
		
		<aside>
			<form>
				<table>
					<tr class="trow1">
						<th colspan="2">
							RM 199 per night<br/><hr class="line1"/>
						</th>
					</tr>
					
					<tr class="trow2">
						<th colspan="2">
							Date &amp; Guest selection<br/><hr class="line2"/>
						</th>
					</tr>
					
					<tr class="trow3">
						<td>
							Check in
						</td>
						<td>
							<input class="form-ctrl" type="date" name="date"/>
						</td>
					</tr>
					
					<tr class="trow4">
						<td>
							Check out
						</td>
						<td>
							<input class="form-ctrl" type="date" name="date"/>
						</td>
					</tr>
					
					<tr class="trow5">
						<td>
							Guest
						</td>
						<td>
							<select class="form-ctrl" name="guest" size="1">
								<option value="1" selected="selected">1 Guest</option>
								<option value="2">2 Guests</option>
								<option value="3">3 Guests</option>
								<option value="4">4 Guests</option>
								<option value="5">5 Guests</option>
								<option value="6">6 Guests</option>
								<option value="7">7 Guests</option>
								<option value="8">8 Guests</option>
								<option value="9">9 Guests</option>
								<option value="10">10 Guests</option>
							</select>
							
						</td>
					</tr>
					
					<tr class="trow6">
						<td colspan="2">
							<hr class="line3"/><a href="enquiry.php" onclick="nameStore()" class="booknow">Book Now</a>
						</td>
					</tr>
				</table>
			</form>
		</aside>
	
		<table class="specification">
			<tr>
				<td><img class="guest" src="images/icon-guest.svg" alt="Guests bullet"/>6 guests</td>
				<td><img class="bedroom" src="images/bath.png" alt="Bedroom bullet"/>3 bedrooms</td>
				<td><img class="bed" src="images/bed.png" alt="Bed bullet"/>4 beds</td>
				<td><img class="bath" src="images/bath.png" alt="Bathroom bullet"/>3 bathrooms</td>
			</tr>
		</table>
		
		<p class="product_content">A cozy and spacious 3 room 3 bath sea-view luxurious apartment situated beside Sutera Harbour Resort overlooking the South China Sea. Located on top of the Imago Shopping Mall, the place is a paradise for shoppers and food lovers.</p>
		
		<h2 class="product_h2">The space</h2>
		<p class="product_content">The Loft is located on top of the Imago Shopping Mall. It is the most popular shopping Mall in Kota Kinabalu and a haven for visitors and tourists. It is also a gateway to all the other tourist spots.</p>
		<p class="product_content">This is a brand new 3 room 3 bath sea-view apartment. It is located on the top 9th floor and has a beautiful view of the sea where you can see fishing boats, islands and a glimpse of the city centre. It is also very windy during the night.</p>
		<p class="product_content">The apartment is accessible with smart access cards for the lifts and entrance door. Moving in and out of the apartment is easy and convenient.</p>
		
		<h2 class="product_h2">Guest access</h2>		
		<p class="product_content">The apartment is located inside the Mall. Moving about from your apartment to the Mall is by access cards. It is very convenient to walk about as the Mall is big and spacious. </p>
		
		<h2 class="product_h2">Interaction with guests</h2>
		<p class="product_content">The owner live in The Loft as well.Owner can be contacted easily. Anything you want to know about the city or any help required - feel free to ask.</p>
		
		<h2 class="product_h2">Amenities</h2>
		<ul class="amenities">
			<li>Air conditionning</li>
			<li>Free parking on premises</li>
			<li>Kitchen</li>
			<li>Essentials</li>
			<li>TV</li>
			<li>Wifi</li>
		</ul>
		
		<h2 class="product_h2">Location</h2>
		
		<div class="mapouter">
			<div class="gmap_canvas">
				<iframe id="gmap_canvas" src="https://maps.google.com/maps?q=Imago%20Shopping%20Mall&t=&z=13&ie=UTF8&iwloc=&output=embed"></iframe>
			</div>
		</div>
		
	</article>
	
<?php include 'include/footer.php';?>

</body>

</html>