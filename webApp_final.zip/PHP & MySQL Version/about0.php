 <!DOCTYPE html>
<html lang="en">

<head>
	<title>TheBest | TheBest</title>
	<meta charset="utf-8" />
	<meta name="Author" content="TheBest" />
	<meta name="Description" content="rent,best,house" />
	<meta name="Keywords" content="rent,best,house" />
	<link rel="stylesheet" type="text/css" href="styles/style.css" />
	<script src="script/dropdown.js"></script>
</head>

<body>
<?php include 'include/header.php';?>

<article class="about">
	<h1 class="aboutus">TheBest</h1>
	<div class="aboutP">
		<table>
			<tr>
				<td>
					<a href="aboutme1.php"><img class="photo" src="images/zhen1.jpg" alt="This is a photo of Siaw Zhen" title="Siaw Zhen" />
					<figcaption>Bong Siaw Zhen</figcaption></a>
				</td>
				
				<td>
					<a href="aboutme2.php"><img class="photo" src="images/dickson1.jpg" alt="This is a photo of Dickson" title="Dickson" />
					<figcaption>Dickson Sim</figcaption></a>
				</td>
				
				<td>
					<a href="aboutme3.php"><img class="photo" src="images/wilson.jpg" alt="This is a photo of Wilson Mah" title="Wilson Mah" />
					<figcaption>Mah Wei Shen</figcaption></a>
				</td>
				
				<td>
					<a href="aboutme4.php"><img class="photo" src="images/peng1.jpg" alt="This is a photo of Peng" title="Peng Hung" />
					<figcaption>Lai Peng Hung</figcaption></a>
				</td>
			</tr>
		</table>
	</div>
			
</article>

<?php include 'include/footer.php';?>

</body>

</html>