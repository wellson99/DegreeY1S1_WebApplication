<!DOCTYPE html>
<html lang="en">

<head>
	<title>7 PAX STUDIO | TheBest</title>
	<meta charset="utf-8" />
	<meta name="Author" content="TheBest" />
	<meta name="Description" content="rent,best,house" />
	<meta name="Keywords" content="rent,best,house" />
	<link rel="stylesheet" type="text/css" href="styles/style.css" />
	<script src="script/script.js"></script>
	<script src="script/dropdown.js"></script>
</head>

<body>	
<?php include 'include/header.php';?>
	
	<article class="productA">
		<br />
		<!--Slideshow implement later-->
		<img class="product_img" src="https://a0.muscache.com/im/pictures/671ee93d-9d11-408f-a4b8-42f22f5da4f8.jpg?aki_policy=xx_large" alt="7 PAX STUDIO" />
		
		<!--Source https://www.airbnb.com/rooms/14821922?location=Pahang%2C%20Malaysia&adults=1&children=0&infants=0&check_in=2018-09-28&check_out=2018-09-29&s=mYuMHI7B-->
		
		<h1 class="product_h1" id="pTitle">7 PAX STUDIO</h1>
		
		<aside>
			<form>
				<table>
					<tr class="trow1">
						<th colspan="2">
							RM 150 per night<br/><hr class="line1"/>
						</th>
					</tr>
					
					<tr class="trow2">
						<th colspan="2">
							Date &amp; Guest selection<br/><hr class="line2"/>
						</th>
					</tr>
					
					<tr class="trow3">
						<td>
							Check in
						</td>
						<td>
							<input class="form-ctrl" type="date" name="date"/>
						</td>
					</tr>
					
					<tr class="trow4">
						<td>
							Check out
						</td>
						<td>
							<input class="form-ctrl" type="date" name="date"/>
						</td>
					</tr>
					
					<tr class="trow5">
						<td>
							Guest
						</td>
						<td>
							<select class="form-ctrl" name="guest" size="1">
								<option value="1" selected="selected">1 Guest</option>
								<option value="2">2 Guests</option>
								<option value="3">3 Guests</option>
								<option value="4">4 Guests</option>
								<option value="5">5 Guests</option>
								<option value="6">6 Guests</option>
								<option value="7">7 Guests</option>
								<option value="8">8 Guests</option>
								<option value="9">9 Guests</option>
								<option value="10">10 Guests</option>
							</select>
							
						</td>
					</tr>
					
					<tr class="trow6">
						<td colspan="2">
							<hr class="line3"/><a href="enquiry.php" onclick="nameStore()" class="booknow">Book Now</a>
						</td>
					</tr>
				</table>
			</form>
		</aside>
	
		<table class="specification">
			<tr>
				<td><img class="guest" src="images/icon-guest.svg" alt="Guests bullet"/>7 guests</td>
				<td><img class="bedroom" src="images/bath.png" alt="Bedroom bullet"/>1 bedrooms</td>
				<td><img class="bed" src="images/bed.png" alt="Bed bullet"/>7 beds</td>
				<td><img class="bath" src="images/bath.png" alt="Bathroom bullet"/>2 bathrooms</td>
			</tr>
		</table>
		
		<p class="product_content">Located along the vibrant Old Klang Road in Kuala Lumpur</p>
		<p class="product_content">Ideal for both leisure and work stays</p>
		<p class="product_content">Perfect for group of friends, couples and professionals</p>
		
		<h2 class="product_h2">The space</h2>
		
		<p class="product_content">Welcome to 7 PAX STUDIO</p>
		<p class="product_content">An Eco-Friendly SOHO that furnished with Natural Pallet Furniture & Come stay in our Eco-Friendly SOHO that furnished with Natural Pallet Furniture & Distinctive Decoration, ideal for Family Vacation & Gathering!</p>
		
		<h2 class="product_h2">Guest access</h2>		
		<p class="product_content">1 Parking spot is available for our guest. Car park access card will be provided with the parking lot being fixed (In front of the Lift).</p>
		<p class="product_content">Direct Access from Parking</p>
		<p class="product_content">Access Card Provided (Lobby & Lift)</p>
		
		<h2 class="product_h2">Interaction with guests</h2>
		<p class="product_content">We’ve installed a Smart-lock system so that you can check in and check out on your own terms, all you need is the passcode and you can stay at the unit safely. Guests can refer to the PDF’s guidebook for rules and regulations. The guidebook will also help on how to perform self check in and check out.</p>
		
		<h2 class="product_h2">Amenities</h2>
		<ul class="amenities">
			<li>Wifi</li>
			<li>Free parking on premises</li>
			<li>Kitchen</li>
			<li>Essentials</li>
			<li>TV</li>
			<li>Air conditioning</li>
			<li>Free parking on premises</li>
			<li>Gym</li>
			<li>Smart lock</li>
			<li>Carbon monoxide detector</li>
		</ul>
		
		<h2 class="product_h2">Location</h2>
		<p class="product_content">ArtHomer’s home is located in Kuala Lumpur, Wilayah Persekutuan Kuala Lumpur, Malaysia.</p>
		<span class="listH">Nearby Townships/Cities </span>
		<ul class="location">
			<li>5 mins to Mid Valley KTM & The Garden (4KM)</li>
			<li>13 mins to Bangsar Village (7KM)</li>
			<li>20 mins to Time Square (10KM)</li>
			<li>20 mins to Pavillion (12KM)</li>
			<li>20 mins to KLCC (13KM)</li>
			<li>25 mins to One Utama (15KM)</li>
		</ul>
		
		<br />
		
		<p class="product_content">3-level lifestyle retail plaza is just right underneath the unit. Wide variety of restaurants, cafes, department stores, bars are just situated right at your walking distance. Guest wouldn’t need to travel to kl city centre just to enjoy good glass of beer with the happening night life situated at Scott garden itself!</p>
		
		<div class="mapouter">
			<div class="gmap_canvas">
				<iframe id="gmap_canvas" src="https://maps.google.com/maps?q=%20Kuala%20Lumpur&t=&z=13&ie=UTF8&iwloc=&output=embed"></iframe>
			</div>
		</div>
		
	</article>

	<?php include 'include/footer.php';?>

</body>

</html>