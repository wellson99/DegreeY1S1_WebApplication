<!DOCTYPE html>
<html lang="en">

<head>
	<title>Sabah | TheBest</title>
	<meta charset="utf-8" />
	<meta name="Author" content="TheBest" />
	<meta name="Description" content="rent,best,house" />
	<meta name="Keywords" content="rent,best,house" />
	<link rel="stylesheet" type="text/css" href="styles/style.css" />
	<script src="script/dropdown.js"></script>
</head>

<body>	
<?php include 'include/header.php';?>
	<article class="subareaA">
		<br />
		
		<h1 class="subarea_h1">Sabah</h1>
		<img class="xsubarea_img" 
		src="https://upload.wikimedia.org/wikipedia/commons/thumb/6/68/Coat_of_arms_of_Sabah.svg/2000px-Coat_of_arms_of_Sabah.svg.png" alt="Sabah" />
		
		<a href="product6.php">
		<div class="subareaC1">
			<img class="product_img" src="https://a0.muscache.com/im/pictures/b18ff6e4-34c2-4cbb-9c05-b9000bccbcc0.jpg?aki_policy=x_large" alt="Hibiscus Beach View" />
			<h2>Hibiscus Beach Retreat</h2>
		</div>
		</a>
		
		<a href="product7.php">
		<div class="subareaC2">
			<img class="product_img " src="https://a0.muscache.com/im/pictures/357fc6b4-97c2-4f5d-995e-e3d076ea5903.jpg?aki_policy=xx_large" alt="Sunbeam Luxury Villa View" />
			<h2>Sunbeam Luxury Villa</h2>
		</div>
		</a>
		
		<a href="product8.php">
		<div class="subareaC3">
			<img class="product_img" src="https://a0.muscache.com/im/pictures/ab2d6325-6ef6-498e-ba81-baea602c75a7.jpg?aki_policy=xx_large" alt="Riverson Soho Room View" />
			<h2>Riverson Soho</h2>
		</div>
		</a>
		
		<a href="product9.php">
		<div class="subareaC4">
			<img class="product_img" src="https://a0.muscache.com/im/pictures/6c458717-5225-406d-afd4-00f67bb14517.jpg?aki_policy=x_large" alt="Sutera Avenue Room View" />
			<h2>Sutera Avenue Suite</h2>
		</div>
		</a>
		
		<a href="product10.php">
		<div class="subareaC5">
			<img class="product_img" src="https://a0.muscache.com/im/pictures/8b9816d7-84ac-485b-a832-60a3c77f3a40.jpg?aki_policy=x_large" alt="Imago Room Sea View"/>
			<h2>Imago Luxurious Room</h2>
		</div>
		</a>
		
		<br />
		<br />
		<br />
		<br />
		<br />
		
	</article>
	
	<?php include 'include/footer.php';?>

</body>

</html>