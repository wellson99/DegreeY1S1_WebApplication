<!DOCTYPE html>
<html lang="en">
<head>
	<title>Enquiry | TheBest</title>
	<meta charset="utf-8" />
	<meta name="Author" content="TheBest" />
	<meta name="Description" content="rent,best,house" />
	<meta name="Keywords" content="rent,best,house" />
	<link rel="stylesheet" type="text/css" href="styles/style.css" />
	<script src="script/dropdown.js"></script>
	
	<style>
	.connected{
		background-color: white;
		text-align:center;
		padding-top:1%;
		padding-bottom:1%;
		border-radius: 80px 0px;
		border:3px solid black;
		width:30%;
		margin: 0 auto;
	}
	
	.bg
	{
		background-color: #F79817;
		width:40%;
		margin: 0 auto;
		margin-top:15%;
		margin-bottom:5%;
		text-align:center;
		padding-top:1%;
		padding-bottom:1%;
		border-radius: 80px 0px;
		border:3px solid black;
	}
	
	</style>
</head>

<body>
<?php include 'include/header.php';?>
	<div class="bg">
	<h1>Booking Confirmed</h1>
	<h2>Thank you and come again</h2>
	</div>
	<?php
		$servername = "localhost";
		$username = "root";
		$password = "";
		$dbname = "enquirydb";
		
		$conn = mysqli_connect($servername, $username, $password, $dbname);
		if(!$conn){
			die("<p class=\"connected\">Connection failed: ". mysqli_connect_error()."</p>");
		}
		else{
			echo "<p class=\"connected\">Successfully connecting to the datebase\n</p>";
			echo "<br />";
		}
		
		$first = $_POST['first'];
		$last = $_POST['last'];
		$email = $_POST['email'];
		$phone = $_POST['phone'];
		$house = $_POST['house'];
		$time = $_POST['time'];
		$street = $_POST['street'];
		$city = $_POST['city'];
		$state = $_POST['state'];
		$postcode = $_POST['postcode'];
		$comment = $_POST['comment'];
		
		$sql = "INSERT INTO enquiry (first, last, email, phone, house, time, street, city, state, postcode, comment) VALUES ('$first', '$last', '$email', '$phone', '$house', '$time', '$street', '$city', '$state', '$postcode', '$comment')";
		
		if (mysqli_query($conn, $sql)) {
		echo "<p class=\"connected\">New record created successfully\n</p>";
		} else {
		 echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
		
	?>
	
	<?php mysqli_close($conn); ?>

<?php include 'include/footer.php';?>

</body>

</html>