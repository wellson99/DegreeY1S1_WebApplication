<!DOCTYPE html>
<html lang="en">

<head>
	<title>Boyan Heights Rainforest  | TheBest</title>
	<meta charset="utf-8" />
	<meta name="Author" content="TheBest" />
	<meta name="Description" content="rent,best,house" />
	<meta name="Keywords" content="rent,best,house" />
	<link rel="stylesheet" type="text/css" href="styles/style.css" />
	<script src="script/script.js"></script>
	<script src="script/dropdown.js"></script>
</head>

<body>	
<?php include 'include/header.php';?>
	
	<article class="productA">
		<br />
		
		<!--Slideshow implement later-->
		<img  class="product_img" src="https://a0.muscache.com/im/pictures/e74e4296-4f94-4a94-86e2-a9e52050f93a.jpg?aki_policy=xx_large" alt="Boyan Heights Rainforest">
		
		<!--Source https://www.airbnb.com/rooms/19958184?location=sarawak%20&adults=1&children=0&infants=0&guests=1&toddlers=0 -->
		
		<h1 class="product_h1" id="pTitle">Boyan Heights Rainforest </h1>
		
		<aside>
			<form>
				<table>
					<tr class="trow1">
						<th colspan="2">
							RM 299 per night<br/><hr class="line1"/>
						</th>
					</tr>
					
					<tr class="trow2">
						<th colspan="2">
							Date &amp; Guest selection<br/><hr class="line2"/>
						</th>
					</tr>
					
					<tr class="trow3">
						<td>
							Check in
						</td>
						<td>
							<input class="form-ctrl" type="date" name="date"/>
						</td>
					</tr>
					
					<tr class="trow4">
						<td>
							Check out
						</td>
						<td>
							<input class="form-ctrl" type="date" name="date"/>
						</td>
					</tr>
					
					<tr class="trow5">
						<td>
							Guest
						</td>
						<td>
							<select class="form-ctrl" name="guest" size="1">
								<option value="1" selected="selected">1 Guest</option>
								<option value="2">2 Guests</option>
								<option value="3">3 Guests</option>
								<option value="4">4 Guests</option>
								<option value="5">5 Guests</option>
								<option value="6">6 Guests</option>
								<option value="7">7 Guests</option>
								<option value="8">8 Guests</option>
								<option value="9">9 Guests</option>
								<option value="10">10 Guests</option>
							</select>
							
						</td>
					</tr>
					
					<tr class="trow6">
						<td colspan="2">
							<hr class="line3"/><a href="enquiry.php" onclick="nameStore()" class="booknow">Book Now</a>
						</td>
					</tr>
				</table>
			</form>
		</aside>
	
		<table class="specification">
			<tr>
				<td><img class="guest" src="images/icon-guest.svg" alt="Guests bullet"/>4 guests</td>
				<td><img class="bedroom" src="images/bath.png" alt="Bedroom bullet"/>1 bedrooms</td>
				<td><img class="bed" src="images/bed.png" alt="Bed bullet"/>2 beds</td>
				<td><img class="bath" src="images/bath.png" alt="Bathroom bullet"/>1 bathrooms</td>
			</tr>
		</table>
		
		<p class="product_content">Nestled in the rainforest along the upper reaches of the Sarawak River next to a Bidayuh Dayak village, Boyan Heights offers a secluded relaxing natural setting, with spectacular views of the rainforest and mountains. Located 31km from the Kuching Centre and conveniently close to many of the major tourism attractions of the region such as Semenggoh Wildlife Sanctuary, Longhouses, Kayaking and Trekking. Your hosts can assist you to organize transport and guides to visit these attractions.</p>
		
		<h2 class="product_h2">The space</h2>
		<p class="product_content">Boyan Heights is modern home architecturally designed to incorporate traditional Sarawakian and longhouse designs. It has been built in the rainforest making the most of the natural environment, the house incorporate many open spaces, natural air flow and light, so even indoors you feel you are in the forest. Each room has been designed with its own unquie outlook into the forest. It comes with 1 King size bed and a Double bunk bed (The bunk bed is NOT suitable for large adult). The large deck and 12m infinity pool over looking the forest and mountains provide a great relaxing area to cool off and enjoy the views and abundant bird life.</p>
		<p class="product_content">We have three rooms available. If you want to book more than one room you can book additional rooms by following the links below (copy and paste the following links<br/>Deluxe Room 2:<br/>Deluxe Room 2:https://www.airbnb.com/rooms/20680358<br/>Deluxe Room 2:Deluxe Room 3:<br/>Deluxe Room 2:https://www.airbnb.com/rooms/20681206</p>
		
		<h2 class="product_h2">Guest access</h2>		
		<p class="product_content">Each room has its own private bathroom and toilet. Guests will have access to their private room, the common TV/sitting room, Kitchen & Dinning room and main living areas including the verandah, BBQ and pool areas.</p>
		
		<h2 class="product_h2">Interaction with guests</h2>
		<p class="product_content">Your hosts will be available to provide any assistance to you during your stay. We can assist you in organizing your activities, transport, recommend place to go, places to eat etc.</p>
		
		<h2 class="product_h2">Other things to note</h2>
		<p class="product_content">Boyan Heights is a private residence, and the hosts live in the residence. The Rooms that are rented out are fully private with their own bathroom and toilet as well as verandah. However, the common areas such as TV room, pool and Kitchen/Dining Room are shared with the hosts and other guests.</p>
		<p class="product_content">As such not all facilities in the house are available for guest use. With the exception of tea and coffee making, Cooking and kitchen facilities are Not available for use by the guests unless by prior permission and arrangement by the hosts.</p>
		
		<h2 class="product_h2">Amenities</h2>
		<ul class="amenities">
			<li>Wifi</li>
			<li>Free parking on premises</li>
			<li>Kitchen</li>
			<li>Cable TV</li>
			<li>Pool</li>
			<li>Hair dryer</li>
		</ul>
		
		<h2 class="product_h2">Location</h2>
		
		<div class="mapouter">
			<div class="gmap_canvas">
				<iframe id="gmap_canvas" src="https://maps.google.com/maps?q=Boyan%20Heights%20Rainforest%20%20&t=&z=13&ie=UTF8&iwloc=&output=embed"></iframe>
			</div>
		</div>
		
	</article>
	
<?php include 'include/footer.php';?>

</body>

</html>