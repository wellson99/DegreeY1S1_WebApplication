<!DOCTYPE html>
<html lang="en">

<head>
	<title>Enquiry | TheBest</title>
	<meta charset="utf-8" />
	<meta name="Author" content="TheBest" />
	<meta name="Description" content="rent,best,house" />
	<meta name="Keywords" content="rent,best,house" />
	<link rel="stylesheet" type="text/css" href="styles/style.css" />
	<script src="script/script.js"></script>
	<script src="script/dropdown.js"></script>
</head>

<body>
<?php include 'include/header.php';?>

<article class="formA">
	<h1 class="formh1">Please Enter Your Information</h1>
	<input type="text" name="subject" id="subject"/>
	
	<form id="form" method="post" action="enquiry_process.php" novalidate="novalidate">
		<fieldset>
			<table>
				<tr>
					<td class="asdasd"><label for="first">First Name</label></td>
					<td><input type="text" id="first" name="first" maxlength="25" required="required" /></td>
								
					<td><label for="last">Last Name</label></td>
					<td><input type="text" id="last" name="last" maxlength="25" required="required" /></td>
				</tr>
				
				<tr>
					<td class="asdasd"><label for="email">Email Address</label></td>
					<td><input type="text" id="email" name="email" required="required"/></td>
					

					
					<td><label for="phone">Phone Number</label></td>
					<td><input type="text" id="phone" name="phone" maxlength="10" placeholder="012345678(9)" required="required"/></td>
				</tr>
				
				<tr>
					<td class="asdasd"><label for="house">House</label></td>
					<td><select name="house" id="house" required="required" onclick="storeHouse()" ></select></td>
					
					
					
					<td><label for="time">Rental Duration</label></td>
					<td><input type="text" id="time" name="time" min="1" required="required" placeholder="Minimum 1 Day" /></td>
				</tr>
				
			</table>
		</fieldset>
		
		<br />
		
		<fieldset>
			<legend>Address</legend>
			<table>
				<tr>
					<td><label for="street">Street Address</label></td>
					<td><input type="text" id="street" name="street" maxlength="40" required="required" /></td>
					
					<td class="midspace2"></td>
					
					<td><label for="city">City/Town</label></td>
					<td><input type="text" id="city" name="city" maxlength="20" required="required" /></td>
				</tr>
				
				<tr>
					<td><label for="state">State</label></td>
					<td><select name="state" id="state" required="required">
						<option value="Kuala Lumpur">Kuala Lumpur</option>
						<option value="Labuan">Labuan</option>
						<option value="Putrajaya">Putrajaya</option>
						<option value="Johor">Johor</option>
						<option value="Kedah">Kedah</option>
						<option value="Kelantan">Kelantan</option>
						<option value="Malacca">Malacca</option>
						<option value="Negeri Sembilan">Negeri Sembilan</option>
						<option value="Pahang">Pahang</option>
						<option value="Perak">Perak</option>
						<option value="Perlis">Perlis</option>
						<option value="Penang">Penang</option>
						<option value="Sabah">Sabah</option>
						<option value="Sarawak">Sarawak</option>
						<option value="Selangor">Selangor</option>
						<option value="Terengganu">Terengganu</option>
						</select>
					</td>
					
					<td class="midspace2"></td>
					
					<td><label for="postcode">Postcode</label></td>
					<td><input type="text" id="postcode" name="postcode" required="required" /></td>

				</tr>
			</table>
		</fieldset>
		<br />
		<fieldset>
			<legend>Feedback</legend>
			<table>
				<tr>
					<td><label for="comment">Comment</label></td>
					<td><textarea name="comment" id="comment" rows="3" cols="40"></textarea></td>
				</tr>
			</table>
		</fieldset>
		
		<p class="srbutton">
		<input type="submit" value="Submit" />
		<input type="reset" value="Reset" />
		</p>
	</form>

</article>

<?php include 'include/footer.php';?>

</body>

</html>