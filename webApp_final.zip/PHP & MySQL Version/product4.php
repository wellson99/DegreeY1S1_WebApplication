<!DOCTYPE html>
<html lang="en">

<head>
	<title>Riverbank Suites | TheBest</title>
	<meta charset="utf-8" />
	<meta name="Author" content="TheBest" />
	<meta name="Description" content="rent,best,house" />
	<meta name="Keywords" content="rent,best,house" />
	<link rel="stylesheet" type="text/css" href="styles/style.css" />
	<script src="script/script.js"></script>
	<script src="script/dropdown.js"></script>
</head>

<body>	
<?php include 'include/header.php';?>
	
	<article class="productA">
		<br />
		
		<!--Slideshow implement later-->
		<img  class="product_img" src="https://a0.muscache.com/im/pictures/3b3ab58a-6c67-44d9-bc78-dde563dfeb3c.jpg?aki_policy=xx_large" alt="Riverbank Suites">
		
		<!--Source https://www.airbnb.com/rooms/16797483?adults=1&children=0&infants=0&guests=1 -->
		
		<h1 class="product_h1" id="pTitle">Riverbank Suites</h1>
		
		<aside>
			<form>
				<table>
					<tr class="trow1">
						<th colspan="2">
							RM 199 per night<br/><hr class="line1"/>
						</th>
					</tr>
					
					<tr class="trow2">
						<th colspan="2">
							Date &amp; Guest selection<br/><hr class="line2"/>
						</th>
					</tr>
					
					<tr class="trow3">
						<td>
							Check in
						</td>
						<td>
							<input class="form-ctrl" type="date" name="date"/>
						</td>
					</tr>
					
					<tr class="trow4">
						<td>
							Check out
						</td>
						<td>
							<input class="form-ctrl" type="date" name="date"/>
						</td>
					</tr>
					
					<tr class="trow5">
						<td>
							Guest
						</td>
						<td>
							<select class="form-ctrl" name="guest" size="1">
								<option value="1" selected="selected">1 Guest</option>
								<option value="2">2 Guests</option>
								<option value="3">3 Guests</option>
								<option value="4">4 Guests</option>
								<option value="5">5 Guests</option>
								<option value="6">6 Guests</option>
								<option value="7">7 Guests</option>
								<option value="8">8 Guests</option>
								<option value="9">9 Guests</option>
								<option value="10">10 Guests</option>
							</select>
							
						</td>
					</tr>
					
					<tr class="trow6">
						<td colspan="2">
							<hr class="line3"/><a href="enquiry.php" onclick="nameStore()" class="booknow">Book Now</a>
						</td>
					</tr>
				</table>
			</form>
		</aside>
	
		<table class="specification">
			<tr>
				<td><img class="guest" src="images/icon-guest.svg" alt="Guests bullet"/>8 guests</td>
				<td><img class="bedroom" src="images/bath.png" alt="Bedroom bullet"/>8 bedrooms</td>
				<td><img class="bed" src="images/bed.png" alt="Bed bullet"/>4 beds</td>
				<td><img class="bath" src="images/bath.png" alt="Bathroom bullet"/>3 bathrooms</td>
			</tr>
		</table>
		
		<p class="product_content">Perched on the Sarawak River in vibrant city centre</p>
		<p class="product_content">Next to 5 star hotels, shopping centres, traditional shops and many eateries</p>
		<p class="product_content">Corner suite, high level facing the most interesting part of the river and waterfront </p>
		<p class="product_content">Next to waterfront walk </p>
		
		<h2 class="product_h2">The space</h2>
		<p class="product_content">This house is very spacious, with en-suite bathroom in all 3 bedrooms. If you love timber, you will love this place!</p>
		
		<h2 class="product_h2">Guest access</h2>		
		<p class="product_content">Lift access cards will be provided to go up and down the apartment. Car park access card will also be provided if you have a car.</p>
		
		<h2 class="product_h2">Interaction with guests</h2>
		<p class="product_content">Gary and Kelly, our co-hosts in Kuching, will welcome guests personally for check in.<br/>I am based in Kuala Lumpur, but please feel free to contact me if you wish to.<br/>We offer 24 hours assistance should you need. The numbers are provided for in the apartment.</p>
		
		<h2 class="product_h2">Other things to note</h2>
		<p class="product_content">1) Please look after your children when on the balconies and in the apartment as it is not child proof. See balcony photos where there is an air con compressor covered with wood which also serves as bench. Do not let them climb here.</p>
		<p class="product_content">2) One carpark spot at the basement is available upon request. We will provide you with the transponder card and parking lot number should you require it.</p>
		<p class="product_content">3) There is a mosque down the river. There is a prayer call every morning before 6am. This is a part of the local culture. If you are a light sleeper, do have some comfortable ear plugs ready. Keep balcony doors and windows closed.</p>
		<p class="product_content">4)This is a lively area. The villagers sing sometimes during the day and at night from across the river. Please make sure to call us immediately ( and not text) if it becomes a bother. There will be traffic noises at times.</p>
		<p class="product_content">5) Please inform the total number of guests including children below and above two years old. As our rates are low, only two infants (children below 2 years) may stay without charge. The rest of the infants will be paying guests at RM55 per child per night. No wheels are allowed inside the apartment other than strollers ( at entrance foyer only)</p>
		<p class="product_content">6) Early check-in and late checkout can be arranged provided that there are no incoming and outgoing guests. We can assist with baggage storage. Please inquire.</p>
		<p class="product_content">7) This is a self catering apartment. Depending on the length of stay, change of towels and bedsheets will incur additional charges. Mid stay housekeeping can be provided at an additional charge. Please inquire.</p>
		<p class="product_content">8) Please note the entrance barrier height to car park is 6ft 4in. Vehicles like Toyota Hiace will not be able to pass through. Those with height like Toyota Alphard will not be a problem.</p>
		<p class="product_content">9) We ask for your understanding that we are not a 5 star hotel and not to expect us to be like one. Our price is considered very low by many.</p>
		
		<h2 class="product_h2">Amenities</h2>
		<ul class="amenities">
			<li>Wifi</li>
			<li>Free parking on premises</li>
			<li>Kitchen</li>
			<li>Cable TV</li>
			<li>Pool</li>
			<li>Hair dryer</li>
		</ul>
		
		<h2 class="product_h2">Location</h2>
		
		<div class="mapouter">
			<div class="gmap_canvas">
				<iframe id="gmap_canvas" src="https://maps.google.com/maps?q=Riverbank%20Suites&t=&z=13&ie=UTF8&iwloc=&output=embed"></iframe>
			</div>
		</div>
		
	</article>
	
<?php include 'include/footer.php';?>

</body>

</html>