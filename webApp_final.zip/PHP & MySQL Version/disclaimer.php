<!DOCTYPE html>
<html lang="en">

<head>
	<title>Disclaimer | TheBest</title>
	<meta charset="utf-8" />
	<meta name="Author" content="TheBest" />
	<meta name="Description" content="rent,best,house" />
	<meta name="Keywords" content="rent,best,house" />
	<link rel="stylesheet" type="text/css" href="styles/style.css" />
	<script src="script/dropdown.js"></script>
</head>

<body>
<?php include 'include/header.php';?>

<article class="disclaimerA">

	<h1 class="disclaimerh1">Disclaimer</h1>
	
	<div class="disclaimerlist">
	<ul>
		<li>This website is created mainly for educational and non-commercial use only. It is a partial fulfillment for completion of unit COS10011 - Creating Web Applications offered in Swinburne University of Technology, Sarawak Campus for Semester 2, 2018.</li>
		<li>The web-master and author(s) do not represent the business entity.</li>
		<li>The content of the pages of this website might be out-dated or inaccurate, thus, the author(s) and web-master does not take any responsibility for incorrect information disseminate or cited from this website.</li>
		<li>If you believe that information of any kind on this website is an infringement of copyright in material in which you either own copyright or are authorized to exercise the rights of a copyright owner, kindly contact the web-master <a href="mailto:101208944@students.swinburne.edu.my">(101208944@students.swinburne.edu.my)</a> for removal.</li>
	</ul>
	</div>
	
</article>

<?php include 'include/footer.php';?>

</body>

</html>