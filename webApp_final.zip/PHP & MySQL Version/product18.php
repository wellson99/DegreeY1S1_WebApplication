<!DOCTYPE html>
<html lang="en">

<head>
	<title>All-You-Need Duplex | TheBest</title>
	<meta charset="utf-8" />
	<meta name="Author" content="TheBest" />
	<meta name="Description" content="rent,best,house" />
	<meta name="Keywords" content="rent,best,house" />
	<link rel="stylesheet" type="text/css" href="styles/style.css" />
	<script src="script/script.js"></script>
	<script src="script/dropdown.js"></script>
</head>

<body>	
<?php include 'include/header.php';?>
	
	<article class="productA">
		<br />
		
		<!--Slideshow implement later-->
		<img class="product_img" src="https://a0.muscache.com/im/pictures/f629fd48-4e1d-404e-8c5d-3f51da091c3f.jpg?aki_policy=xx_large" alt="All-You-Need Duplex" />
		
		<!--Source https://www.airbnb.com/rooms/21441759?location=Petaling%20Jaya%20Selangor%20Malaysia&adults=1&children=0&infants=0&s=33XBNoT5-->
		
		<h1 class="product_h1" id="pTitle">All-You-Need Duplex</h1>
		
		<aside>
			<form>
				<table>
					<tr class="trow1">
						<th colspan="2">
							RM 139 per night<br/><hr class="line1"/>
						</th>
					</tr>
					
					<tr class="trow2">
						<th colspan="2">
							Date &amp; Guest selection<br/><hr class="line2"/>
						</th>
					</tr>
					
					<tr class="trow3">
						<td>
							Check in
						</td>
						<td>
							<input class="form-ctrl" type="date" name="date"/>
						</td>
					</tr>
					
					<tr class="trow4">
						<td>
							Check out
						</td>
						<td>
							<input class="form-ctrl" type="date" name="date"/>
						</td>
					</tr>
					
					<tr class="trow5">
						<td>
							Guest
						</td>
						<td>
							<select class="form-ctrl" name="guest" size="1">
								<option value="1" selected="selected">1 Guest</option>
								<option value="2">2 Guests</option>
								<option value="3">3 Guests</option>
								<option value="4">4 Guests</option>
								<option value="5">5 Guests</option>
								<option value="6">6 Guests</option>
								<option value="7">7 Guests</option>
								<option value="8">8 Guests</option>
								<option value="9">9 Guests</option>
								<option value="10">10 Guests</option>
							</select>
							
						</td>
					</tr>
					
					<tr class="trow6">
						<td colspan="2">
							<hr class="line3"/><a href="enquiry.php" onclick="nameStore()" class="booknow">Book Now</a>
						</td>
					</tr>
				</table>
			</form>
		</aside>
	
		<table class="specification">
			<tr>
				<td><img class="guest" src="images/icon-guest.svg" alt="Guests bullet"/>6 guests</td>
				<td><img class="bedroom" src="images/bath.png" alt="Bedroom bullet"/>1 bedrooms</td>
				<td><img class="bed" src="images/bed.png" alt="Bed bullet"/>3 beds</td>
				<td><img class="bath" src="images/bath.png" alt="Bathroom bullet"/>1 bathrooms</td>
			</tr>
		</table>
		
		<p class="product_content">*Self check-in and check-out, with a clear guided manual.<br/>
			*Business travellers to family-friendly loft<br/>
			*Located on the 18th floor with greenery view<br/>
			*Peaceful and quiet<br/>
			*Tight security <br/>
			*Close vicinity to IKEA, The Curve, Tesco, Ikano, and KidZania<br/>
			*Easy access to restaurants, bars, cafes, and convenient stores<br/>
			*100mbps high speed internet<br/>
			*2x Air-conditioners and 4x Fans <br/>
			*Chinese TV Box of 10,000++ Movies and Dramas<br/>
			*1x Free Parking Space</p>
		
		<h2 class="product_h2">The space</h2>
		<p class="product_content">*2x Tatami-styled Queen beds*<br/>
			*1x Sofa bed*<br/> 
			*Bean Bag Area*<br/>
			*Tatami Area*</p>
		
		<h2 class="product_h2">Guest access</h2>		
		<p class="product_content">Facilities that are available within the building but with fees applied:</p>
		<p class="product_content">*24-hour Anytime Fitness*<br/>
			*24-hour Self-service Laundry Facilities*</p>
		
		<h2 class="product_h2">Interaction with guests</h2>
		<p class="product_content">Easily contactable with prompt reply. Able to converse in English/Mandarin/Cantonese/Malay.</p>
		
		<h2 class="product_h2">Amenities</h2>
		<ul class="amenities">
			<li>Wifi</li>
			<li>Free parking on premises</li>
			<li>Kitchen</li>
			<li>Iron</li>
			<li>Cable TV</li>
			<li>Elevator</li>
		</ul>
		
		<h2 class="product_h2">Location</h2>
		
		<div class="mapouter">
			<div class="gmap_canvas">
				<iframe id="gmap_canvas" src="https://maps.google.com/maps?q=%20Petaling%20Jaya&t=&z=13&ie=UTF8&iwloc=&output=embed"></iframe>
			</div>
		</div>
		
	</article>
	
	<?php include 'include/footer.php';?>

</body>

</html>