<!DOCTYPE html>
<html lang="en">
<head>
	<title>Enquiry | TheBest</title>
	<meta charset="utf-8" />
	<meta name="Author" content="TheBest" />
	<meta name="Description" content="rent,best,house" />
	<meta name="Keywords" content="rent,best,house" />
	<link rel="stylesheet" type="text/css" href="styles/style.css" />
	<script src="script/dropdown.js"></script>
	
	<style>
	.connected{
		background-color: white;
		text-align:center;
		padding-top:1%;
		padding-bottom:1%;
		border-radius: 80px 0px;
		border:3px solid black;
		width:30%;
		margin: 0 auto;
		margin-top: 5%;
	}	
	
	.tt{
		background-color:#f79817;
		width:50%;
		text-align:center;
		margin-bottom:5%;
	}
	
	.tt th{
		padding-left:2%;
		padding-right:2%;
		background-color: black;
		color:white;
		text-align:center;
	}
	
	.tt td{
		padding-left:2%;
		padding-right:2%;
		text-align:center;
	}
	</style>
</head>

<body>
<?php include 'include/header.php';?>

<?php
	/* To open enquiries from database http://localhost/assign3/view_enquiries.php */
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "enquirydb";
		
	$conn = mysqli_connect($servername, $username, $password, $dbname);
	if(!$conn){
		die("<p class=\"connected\">Connection failed: ". mysqli_connect_error() . "</p>");
	}
	else{
		echo "<p class=\"connected\">Succuessfully connecting to the datebase</p>\n";
		echo "<br />";
	}
	
	$data = "SELECT * FROM enquiry";
	$result = mysqli_query($conn, $data);
	
	echo "<table class='tt' border='1'>";
	echo "<tr><th>First name</th>
			  <th>Last name</th>
			  <th>Email</th>
			  <th>Phone</th>
			  <th>House</th>
			  <th>Time</th>
			  <th>Street</th>
			  <th>City</th>
			  <th>State</th>
			  <th>Postcode</th>
			  <th>Comment</th></tr>";
	
	$row = mysqli_fetch_assoc($result);
	
	while ($row){
		echo "<tr><td>{$row['first']}</td>";
		echo "<td>{$row['last']}</td>";
		echo "<td>{$row['email']}</td>";
		echo "<td>{$row['phone']}</td>";
		echo "<td>{$row['house']}</td>";
		echo "<td>{$row['time']}</td>";
		echo "<td>{$row['street']}</td>";
		echo "<td>{$row['city']}</td>";
		echo "<td>{$row['state']}</td>";
		echo "<td>{$row['postcode']}</td>";
		echo "<td>{$row['comment']}</td></tr>";
		$row = mysqli_fetch_assoc($result);
	}
	echo "</table>";
?>

<?php include 'include/footer.php';?>

</body>
</html>