<!DOCTYPE html>
<html lang="en">

<head>
	<title>Pahang | TheBest</title>
	<meta charset="utf-8" />
	<meta name="Author" content="TheBest" />
	<meta name="Description" content="rent,best,house" />
	<meta name="Keywords" content="rent,best,house" />
	<link rel="stylesheet" type="text/css" href="styles/style.css" />
	<script src="script/dropdown.js"></script>
</head>

<body>	
<?php include 'include/header.php';?>
	
	<article class="subareaA">
		<br />
		
		<h1 class="subarea_h1">Pahang</h1>
		<img class="xsubarea_img" 
		src="https://vectorise.net/logo/wp-content/uploads/2017/02/logo-sultan-Pahang-01.png" alt="Pahang" />
		
		<a href="product11.php">
		<div class="subareaC1">
			<img class="product_img" src="https://a0.muscache.com/im/pictures/bd2db486-17e5-4e96-a99d-8fae2599564f.jpg?aki_policy=xx_large" alt="DR.SHAZ SUMMER HOUSE" />
			<h2>DR.SHAZ SUMMER HOUSE</h2>
		</div>
		</a>
		
		<a href="product12.php">
		<div class="subareaC2">
			<img class="product_img" src="https://a0.muscache.com/im/pictures/671ee93d-9d11-408f-a4b8-42f22f5da4f8.jpg?aki_policy=xx_large" alt="7 PAX STUDIO" />
			<h2>7 PAX STUDIO</h2>
		</div>
		</a>
		
		<a href="product13.php">
		<div class="subareaC3">
			<img class="product_img" src="https://a0.muscache.com/im/pictures/9616e3df-10e7-48fd-b995-e67e86e6bfba.jpg?aki_policy=xx_large" alt="The Scott Garden" />
			<h2>The Scott Garden</h2>
		</div>
		</a>
		
		<a href="product14.php">
		<div class="subareaC4">
			<img class="product_img" src="https://a0.muscache.com/im/pictures/c0125d65-ffdf-495c-b424-9a40911e118e.jpg?aki_policy=x_large" alt="The Nordic" />
			<h2>The Nordic</h2>
		</div>
		</a>
		
		<a href="product15.php">
		<div class="subareaC5">
			<img class="product_img" src="https://a0.muscache.com/im/pictures/73b0307d-17db-42bb-a6f2-7151ada4c68f.jpg?aki_policy=xx_large" alt="Home Wood" />
			<h2>Home Wood</h2>
		</div>
		</a>
		
		<br />
		<br />
		<br />
		<br />
		<br />
		
	</article>
	
<?php include 'include/footer.php';?>

</body>

</html>