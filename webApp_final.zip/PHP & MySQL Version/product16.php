<!DOCTYPE html>
<html lang="en">

<head>
	<title>The Happiness Home 2 | TheBest</title>
	<meta charset="utf-8" />
	<meta name="Author" content="TheBest" />
	<meta name="Description" content="rent,best,house" />
	<meta name="Keywords" content="rent,best,house" />
	<link rel="stylesheet" type="text/css" href="styles/style.css" />
	<script src="script/script.js"></script>
	<script src="script/dropdown.js"></script>
</head>

<body>	
<?php include 'include/header.php';?>
	
	<article class="productA">
		<br />
		
		<!--Slideshow implement later-->
		<img  class="product_img" src="https://a0.muscache.com/im/pictures/30a9771b-47f5-4bcb-9667-42e398f0ff89.jpg?aki_policy=x_large" alt="The Happiness Home 2">
		
		<!--Source https://www.airbnb.com/rooms/9243146?location=Selangor%20Malaysia&adults=1&children=0&infants=0&s=yig0o5oU-->
		
		<h1 class="product_h1" id="pTitle">The Happiness Home 2</h1>
		
		<aside>
			<form>
				<table>
					<tr class="trow1">
						<th colspan="2">
							RM 109 per night<br/><hr class="line1"/>
						</th>
					</tr>
					
					<tr class="trow2">
						<th colspan="2">
							Date &amp; Guest selection<br/><hr class="line2"/>
						</th>
					</tr>
					
					<tr class="trow3">
						<td>
							Check in
						</td>
						<td>
							<input class="form-ctrl" type="date" name="date"/>
						</td>
					</tr>
					
					<tr class="trow4">
						<td>
							Check out
						</td>
						<td>
							<input class="form-ctrl" type="date" name="date"/>
						</td>
					</tr>
					
					<tr class="trow5">
						<td>
							Guest
						</td>
						<td>
							<select class="form-ctrl" name="guest" size="1">
								<option value="1" selected="selected">1 Guest</option>
								<option value="2">2 Guests</option>
								<option value="3">3 Guests</option>
								<option value="4">4 Guests</option>
								<option value="5">5 Guests</option>
								<option value="6">6 Guests</option>
								<option value="7">7 Guests</option>
								<option value="8">8 Guests</option>
								<option value="9">9 Guests</option>
								<option value="10">10 Guests</option>
							</select>
							
						</td>
					</tr>
					
					<tr class="trow6">
						<td colspan="2">
							<hr class="line3"/><a href="enquiry.php" onclick="nameStore()" class="booknow">Book Now</a>
						</td>
					</tr>
				</table>
			</form>
		</aside>
	
		<table class="specification">
			<tr>
				<td><img class="guest" src="images/icon-guest.svg" alt="Guests bullet"/>6 guests</td>
				<td><img class="bedroom" src="images/bath.png" alt="Bedroom bullet"/>1 bedrooms</td>
				<td><img class="bed" src="images/bed.png" alt="Bed bullet"/>4 beds</td>
				<td><img class="bath" src="images/bath.png" alt="Bathroom bullet"/>2 bathrooms</td>
			</tr>
		</table>
		
		<p class="product_content">Duplex lodge unit situated in The Scott Garden with 4 beds 
		*( 2 Queen Beds + 2 Single Beds)*
		Strategically located in a prime district along the vibrant Old Klang Road in Kuala Lumpur, it is easy reach and close proximity to Mid Valley Mega Mall.</p>
		
		<h2 class="product_h2">The space</h2>
		<p class="product_content">The Happiness Home is designed and decorated alike your home sweet home, we aim to maximize your happiness with a homestay experience with us. This fantastic duplex unit design has a large bed room up-stairs and a spacious living hall and kitchen down-stairs. 
		</p>
		
		<span class="listH">Up-stairs (Bed Room):</span>
		
		<ul class="product_content space">
		<li>1 Queen Size Bed </li>
		<li>2 single Bed </li>
		<li>1 Bathroom with water heater </li>
		<li>Air-conditione</li>
		<li>Hair Dryer</li>
		<li>2 Towels</li>
		</ul>
		
		<span class="listH">Living Room</span>
		
		<ul class="product_content space">
		<li>1 Queen Size Bed </li>
		<li>2 Seater Sofa </li>
		<li>40 “ LED TV</li>
		<li>Air- Conditioner</li>
		<li>High Speed Free Internet WIFI </li>
		<li>Hypp TV Channel</li>
		</ul>
		
		<span class="listH">Kitchen</span>
		
		<ul class="product_content space">
		<li>Table for 4 +2</li>
		<li>Complimentary Coffee and Tea </li>
		<li>Dinning Tools </li>
		<li>Kettle</li>
		<li>Washing Machine</li>
		<li>Fridge</li>
		</ul>
		
		<h2 class="product_h2">Guest access</h2>		
		<p class="product_content">Guests are able to access to all the facilities on Level 5 with Access Card. Facilities include: Gymnasium, Jogging Track, Infinity Pool, Lush Landscaping with water canals, BBQ pit (require prior booking & security deposit).</p>
		
		<h2 class="product_h2">Interaction with guests</h2>
		<p class="product_content">Check in:/ Check out: 
		Please note that this property is independently operated by individual owner. It is a private unit of vacation home and therefore does not have a check in counter. A session of “Meet & Greet" for key handover and familiarization of the property will be arranged prior to check in.</p>
		
		<h2 class="product_h2">Amenities</h2>
		<ul class="amenities">
			<li>Wifi</li>
			<li>Free parking on premises</li>
			<li>Kitchen</li>
			<li>Iron</li>
			<li>Hair dryer</li>
			<li>Washer</li>
		</ul>
		
		<h2 class="product_h2">Location</h2>
		<div class="mapouter">
			<div class="gmap_canvas">
				<iframe id="gmap_canvas" src="https://maps.google.com/maps?q=%20Kuala%20Lumpur&t=&z=13&ie=UTF8&iwloc=&output=embed"></iframe>
			</div>
		</div>
		
	</article>
	
	<?php include 'include/footer.php';?>

</body>

</html>