<?php
	echo"
	<footer>
			<p>&copy; <a href=\"about0.html\" title=\"Developers\"><span class=\"teamname\">2018 TheBest</span></a> | Page developed by - Dickson - Wilson - Siaw Zhen - Peng | Last updated: 25/11/2018 1:16am</p>
	</footer>
	"
?>