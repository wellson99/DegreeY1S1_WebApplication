<?php
	echo" 
	<header>
		<nav class=\"navbar\">
			<ul class=\"navigation\">
				<li><a href=\"index.php\"><img src=\"images/logo.png\" class=\"logo\" alt=\"This is a logo\" title=\"Click here to go to homepage\" /></a></li>
					
				<li class=\"MenuSelect\"><a class=\"selection\">Area</a>
					<div class=\"dropdown-selection\">
					<a href=\"sarawak.php\">Sarawak</a>
					<a href=\"sabah.php\">Sabah</a>
					<a href=\"pahang.php\">Pahang</a>
					<a href=\"selangor.php\">Selangor</a>
					</div>
				</li>
					
				<li class=\"MenuSelect\"><a href=\"enquiry.php\" class=\"selection\">Enquiry</a></li>
					
				<li class=\"MenuSelect\"><a href=\"about0.php\" class=\"selection\">About Us</a>
					<div class=\"dropdown-selection\">
						<a href=\"aboutme1.php\">Siaw Zhen</a>
						<a href=\"aboutme2.php\">Dickson</a>
						<a href=\"aboutme3.php\">Wilson</a>
						<a href=\"aboutme4.php\">Peng</a>
					</div>
				</li>
					
				<li class=\"MenuSelect\"><a href=\"disclaimer.php\" class=\"selection\">Disclaimer</a></li>
					
				<li class=\"MenuSelect\"><a href=\"enhancements.php\" class=\"selection\">Enhancement</a></li>

			</ul>
		</nav>
	</header>"
?>