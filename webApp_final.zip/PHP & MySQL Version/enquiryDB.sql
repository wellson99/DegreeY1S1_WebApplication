-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 25, 2018 at 01:44 PM
-- Server version: 10.1.35-MariaDB
-- PHP Version: 7.2.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `enquirydb`
--
CREATE DATABASE IF NOT EXISTS `enquirydb` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `enquirydb`;

-- --------------------------------------------------------

--
-- Table structure for table `enquiry`
--

CREATE TABLE `enquiry` (
  `first` varchar(255) COLLATE utf8_bin NOT NULL,
  `last` varchar(255) COLLATE utf8_bin NOT NULL,
  `email` varchar(255) COLLATE utf8_bin NOT NULL,
  `phone` int(255) NOT NULL,
  `house` varchar(11) COLLATE utf8_bin NOT NULL,
  `time` int(3) NOT NULL,
  `street` varchar(45) COLLATE utf8_bin NOT NULL,
  `city` varchar(30) COLLATE utf8_bin NOT NULL,
  `state` varchar(20) COLLATE utf8_bin NOT NULL,
  `postcode` int(6) NOT NULL,
  `comment` varchar(1000) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `enquiry`
--

INSERT INTO `enquiry` (`first`, `last`, `email`, `phone`, `house`, `time`, `street`, `city`, `state`, `postcode`, `comment`) VALUES
('Lai', 'Peng', 'penggod@gmail.com', 123456778, 'Sweet Home ', 1, 'No.46, Jalan Seladah, Everbright Jaya, L', 'Kuching', 'Sarawak', 93350, 'Test');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
