<!DOCTYPE html>
<html lang="en">

<head>
	<title>Selangor | TheBest</title>
	<meta charset="utf-8" />
	<meta name="Author" content="TheBest" />
	<meta name="Description" content="rent,best,house" />
	<meta name="Keywords" content="rent,best,house" />
	<link rel="stylesheet" type="text/css" href="styles/style.css" />
	<script src="script/dropdown.js"></script>
</head>

<body>	
<?php include 'include/header.php';?>
	
	<article class="subareaA">
		<br />
		
		<h1 class="subarea_h1">Selangor</h1>
		<img class="xsubarea_img" 
		src="http://pngimage.net/wp-content/uploads/2018/06/jata-negeri-selangor-png-2.png" alt="Barefoot Luxury View" />
		
		<a href="product16.php">
		<div class="subareaC1">
			<img class="product_img" src="https://a0.muscache.com/im/pictures/30a9771b-47f5-4bcb-9667-42e398f0ff89.jpg?aki_policy=x_large" alt="The Happiness Home 2" />
			<h2>The Happiness Home 2</h2>
		</div>
		</a>
		
		<a href="product17.php">
		<div class="subareaC2">
			<img class="product_img" src="https://a0.muscache.com/im/pictures/20428719/6b1f87aa_original.jpg?aki_policy=x_large" alt="Cozy Family Suite" />
			<h2>Cozy Family Suite</h2>
		</div>
		</a>
		
		<a href="product18.php">
		<div class="subareaC3">
			<img class="product_img" src="https://a0.muscache.com/im/pictures/f629fd48-4e1d-404e-8c5d-3f51da091c3f.jpg?aki_policy=xx_large" alt="All-You-Need Duplex" />
			<h2>All-You-Need Duplex</h2>
		</div>
		</a>
		
		<a href="product19.php">
		<div class="subareaC4">
			<img class="product_img" src="https://a0.muscache.com/im/pictures/8fe015c0-0eb3-437a-8cb4-5e444bb5ab48.jpg?aki_policy=xx_large" alt="Barefoot Luxury View" />
			<h2>PJ New Suite Studio</h2>
		</div>
		</a>
		
		<a href="product20.php">
		<div class="subareaC5">
			<img class="product_img" src="https://a0.muscache.com/im/pictures/5b889c8b-16dd-4066-a63c-0c19006124ba.jpg?aki_policy=xx_large" alt="Barefoot Luxury View" />
			<h2>ASR NEO DAMANSARA</h2>
		</div>
		</a>
		
		<br />
		<br />
		<br />
		<br />
		<br />
		
	</article>
	
	<?php include 'include/footer.php';?>

</body>

</html>