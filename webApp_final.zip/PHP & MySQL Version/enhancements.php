<!DOCTYPE html>
<html lang="en">

<head>
	<title>Enhancements | TheBest</title>
	<meta charset="utf-8" />
	<meta name="Author" content="TheBest" />
	<meta name="Description" content="rent,best,house" />
	<meta name="Keywords" content="rent,best,house" />
	<link rel="stylesheet" type="text/css" href="styles/style.css" />
	<script src="script/dropdown.js"></script>
</head>

<body>	
<?php include 'include/header.php';?>
	
	<article class="Genhancement">
		
		<h1>Enhancements</h1>
		
		<table>
			<tr>
				<td>
					<a href="enhancements1.php"><img src="images/htmlCss.png" class="imgHtml" alt="HTML CSS Logo"></a>
				</td>
				
				<td class="enSpace"></td>
				
				<td>
					<a href="enhancements2.php"><img src="images/javaS.png" class="imgJava" alt="HTML CSS Logo"></a>
				</td>				
			</tr>
			
			
			
			<tr>
				<td>Enhancement 1</td>
				<td class="enSpace"></td>
				<td>Enhancement 2</td>
			</tr>
		</table>
		
	</article>
	
<?php include 'include/footer.php';?>

</body>

</html>