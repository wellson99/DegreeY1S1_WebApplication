<!DOCTYPE html>
<html lang="en">

<head>
	<title>ASR NEO DAMANSARA | TheBest</title>
	<meta charset="utf-8" />
	<meta name="Author" content="TheBest" />
	<meta name="Description" content="rent,best,house" />
	<meta name="Keywords" content="rent,best,house" />
	<link rel="stylesheet" type="text/css" href="styles/style.css" />
	<script src="script/script.js"></script>
	<script src="script/dropdown.js"></script>
</head>

<body>	
<?php include 'include/header.php';?>
	
	<article class="productA">
		<br />
		
		<!--Slideshow implement later-->
		<img class="product_img" src="https://a0.muscache.com/im/pictures/5b889c8b-16dd-4066-a63c-0c19006124ba.jpg?aki_policy=xx_large" alt="ASR NEO DAMANSARA" />
		
		<!--Source https://www.airbnb.com/rooms/26547249?adults=1&children=0&infants=0&guests=1&s=uL3blZGX-->
		
		<h1 class="product_h1" id="pTitle">ASR NEO DAMANSARA</h1>
		
		<aside>
			<form>
				<table>
					<tr class="trow1">
						<th colspan="2">
							RM 169 per night<br/><hr class="line1"/>
						</th>
					</tr>
					
					<tr class="trow2">
						<th colspan="2">
							Date &amp; Guest selection<br/><hr class="line2"/>
						</th>
					</tr>
					
					<tr class="trow3">
						<td>
							Check in
						</td>
						<td>
							<input class="form-ctrl" type="date" name="date"/>
						</td>
					</tr>
					
					<tr class="trow4">
						<td>
							Check out
						</td>
						<td>
							<input class="form-ctrl" type="date" name="date"/>
						</td>
					</tr>
					
					<tr class="trow5">
						<td>
							Guest
						</td>
						<td>
							<select class="form-ctrl" name="guest" size="1">
								<option value="1" selected="selected">1 Guest</option>
								<option value="2">2 Guests</option>
								<option value="3">3 Guests</option>
								<option value="4">4 Guests</option>
								<option value="5">5 Guests</option>
								<option value="6">6 Guests</option>
								<option value="7">7 Guests</option>
								<option value="8">8 Guests</option>
								<option value="9">9 Guests</option>
								<option value="10">10 Guests</option>
							</select>
							
						</td>
					</tr>
					
					<tr class="trow6">
						<td colspan="2">
							<hr class="line3"/><a href="enquiry.php" onclick="nameStore()" class="booknow">Book Now</a>
						</td>
					</tr>
				</table>
			</form>
		</aside>
	
		<table class="specification">
			<tr>
				<td><img class="guest" src="images/icon-guest.svg" alt="Guests bullet"/>2 guests</td>
				<td><img class="bedroom" src="images/bath.png" alt="Bedroom bullet"/>1 bedrooms</td>
				<td><img class="bed" src="images/bed.png" alt="Bed bullet"/>1 beds</td>
				<td><img class="bath" src="images/bath.png" alt="Bathroom bullet"/>1 bathrooms</td>
			</tr>
		</table>
		
		<p class="product_content">*Great Location at the centre of Damansara <br/>*This studio is Perfect for both vacation and business trip with up to 100Mbps wifi<br/>*Near to MRT Station to get to KL areas</p>
		
		<h2 class="product_h2">The space</h2>
		<p class="product_content">*This apartment is facing beautiful view. The room itself is fully furnished and ready to fulfill your everyday needs.</p>
		<p class="product_content">*If you have any special requests or needs, don't hesitate to contact me for enquire. I'll be glad to help!</p>
		
		<h2 class="product_h2">Guest access</h2>		
		<p class="product_content">* Guests will be liable for any damages done in the premise.<br/>* Guests must return ONE parking access card and ONE room key upon check-out, deposit of RM200 will be forfeited as penalty if it's lost or damaged</p>
		
		<h2 class="product_h2">Interaction with guests</h2>
		<p class="product_content">Our dedicated staff our on hand to help during your stay.</p>
		
		<h2 class="product_h2">Amenities</h2>
		<ul class="amenities">
			<li>Wifi</li>
			<li>Free parking on premises</li>
			<li>Iron</li>
			<li>Kitchen</li>
			<li>Elevator</li>
			<li>Laptop friendly workspace</li>
		</ul>
		
		<h2 class="product_h2">Location</h2>
		
		<div class="mapouter">
			<div class="gmap_canvas">
				<iframe id="gmap_canvas" src="https://maps.google.com/maps?q=DAMANSARA%20PERDANA&t=&z=13&ie=UTF8&iwloc=&output=embed"></iframe>
			</div>
		</div>
		
	</article>
	
	<?php include 'include/footer.php';?>

</body>

</html>