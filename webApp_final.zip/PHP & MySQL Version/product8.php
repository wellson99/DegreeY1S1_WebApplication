<!DOCTYPE html>
<html lang="en">

<head>
	<title>Riverson Soho | TheBest</title>
	<meta charset="utf-8" />
	<meta name="Author" content="TheBest" />
	<meta name="Description" content="rent,best,house" />
	<meta name="Keywords" content="rent,best,house" />
	<link rel="stylesheet" type="text/css" href="styles/style.css" />
	<script src="script/script.js"></script>
	<script src="script/dropdown.js"></script>
</head>

<body>	
<?php include 'include/header.php';?>
	
	<article class="productA">
		<br />
		
		<!--Slideshow implement later-->
		<img class="product_img" src="https://a0.muscache.com/im/pictures/ab2d6325-6ef6-498e-ba81-baea602c75a7.jpg?aki_policy=xx_large" alt="Riverson Soho Room View" />
		
		<!--Source https://www.airbnb.com/rooms/12075731?location=Sabah%20Malaysia&adults=2&children=0&infants=0&home_collection=1&s=8XE1xCE1 -->
		
		<h1 class="product_h1" id="pTitle">Riverson Soho</h1>
		
		<aside>
			<form>
				<table>
					<tr class="trow1">
						<th colspan="2">
							RM 179 per night<br/><hr class="line1"/>
						</th>
					</tr>
					
					<tr class="trow2">
						<th colspan="2">
							Date &amp; Guest selection<br/><hr class="line2"/>
						</th>
					</tr>
					
					<tr class="trow3">
						<td>
							Check in
						</td>
						<td>
							<input class="form-ctrl" type="date" name="date"/>
						</td>
					</tr>
					
					<tr class="trow4">
						<td>
							Check out
						</td>
						<td>
							<input class="form-ctrl" type="date" name="date"/>
						</td>
					</tr>
					
					<tr class="trow5">
						<td>
							Guest
						</td>
						<td>
							<select class="form-ctrl" name="guest" size="1">
								<option value="1" selected="selected">1 Guest</option>
								<option value="2">2 Guests</option>
								<option value="3">3 Guests</option>
								<option value="4">4 Guests</option>
								<option value="5">5 Guests</option>
								<option value="6">6 Guests</option>
								<option value="7">7 Guests</option>
								<option value="8">8 Guests</option>
								<option value="9">9 Guests</option>
								<option value="10">10 Guests</option>
							</select>
							
						</td>
					</tr>
					
					<tr class="trow6">
						<td colspan="2">
							<hr class="line3"/><a href="enquiry.php" onclick="nameStore()" class="booknow">Book Now</a>
						</td>
					</tr>
				</table>
			</form>
		</aside>
	
		<table class="specification">
			<tr>
				<td><img class="guest" src="images/icon-guest.svg" alt="Guests bullet"/>4 guests</td>
				<td><img class="bedroom" src="images/bath.png" alt="Bedroom bullet"/>1 bedrooms</td>
				<td><img class="bed" src="images/bed.png" alt="Bed bullet"/>2 beds</td>
				<td><img class="bath" src="images/bath.png" alt="Bathroom bullet"/>1 bathrooms</td>
			</tr>
		</table>
		
		<p class="product_content">1 Bedroom Suite located in the heart of city centre-Riverson SOHO, with Gleneagles Hospital and Imago Shopping Mall just within walking distances. An ideal staycation for both Business and Leisure travelers for its convenience location to nearby attractions. My place is close to restaurants and dining and is good for couples, solo adventurers, business travelers even small group/families.</p>
		
		<h2 class="product_h2">The space</h2>
		<p class="product_content">1 Bedroom Suite located along the Coastal Highway close to the heart of city centre-The SOHO Riverson, with a block away to Gleneagles Medical Center and few mins walking distance to KK Times Square and Imago Shopping Mall. An ideal staycation for both Business and Leisure travelers for its strategically location where you can easily access to nearby various hotspots.</p>
		<p class="product_content">The new unit comprises of 1 Bedroom Suite with fully furnished of modern and luxurious facilities, open kitchen concept for light cooking, living room and balcony overlooking the pool view.</p>
		<p class="product_content">The room comes with 1 Queen bed and 1 Super Single bed which can accommodate up to 3-4 person. Extra person can be accommodate with 1 Extra bed or mattress upon request. However, kindly note that with the extra bed to be placed inside the room it will be less spacious but still accessible. Housekeeping can be requested 1 day in advance at minimum charges.</p>
		
		<h2 class="product_h2">Guest access</h2>		
		<p class="product_content">The newly SOHO provides recreation facilities including swimming pool with jacuzzi(awesome night swim in sparkle star-lit), gymnasium and common garden, great for healing after a whole day activities. </p>
		
		<h2 class="product_h2">Interaction with guests</h2>
		<p class="product_content">Our dedicated staff our on hand to help during your stay. Communication: We are able to speak English, Mandarin, Cantonese, Hakka & Bahasa Melayu! </p>
		
		<h2 class="product_h2">Amenities</h2>
		<ul class="amenities">
			<li>Air conditionning</li>
			<li>Wifi</li>
			<li>Kitchen</li>
			<li>Free parking on premises</li>
			<li>TV</li>
			<li>Laptop friendly workspace</li>
		</ul>
		
		<h2 class="product_h2">Location</h2>
		
		<div class="mapouter">
			<div class="gmap_canvas">
				<iframe id="gmap_canvas" src="https://maps.google.com/maps?q=Riverson%20Soho%2C%20Jalan%20Coastal%2C%20Kota%20Kinabalu%2C%20Sabah&t=&z=13&ie=UTF8&iwloc=&output=embed" ></iframe>
			</div>
		</div>
		
	</article>
	
<?php include 'include/footer.php';?>

</body>

</html>