<!DOCTYPE html>
<html lang="en">

<head>
	<title>Peng | TheBest</title>
	<meta charset="utf-8" />
	<meta name="Author" content="TheBest" />
	<meta name="Description" content="rent,best,house" />
	<meta name="Keywords" content="rent,best,house" />
	<link rel="stylesheet" type="text/css" href="styles/style.css" />
	<script src="script/dropdown.js"></script>
</head>

<body>
<?php include 'include/header.php';?>

<article class="aboutA">

<p class="name">Lai Peng Hung</p>

<div class="aboutme"> 
<img src="images/peng.jpg" alt="This is a photo of peng" title="Peng" class="pp" />

<p><span class="id">Student id: 101208371</span></p>
<p><span class="course">Course: Computer Science</span></p>
<p>Nickname: Peng</p>
<p>Age: 19</p>
<p>Birthday: 04/11/1999</p>
<p>High School: SMK DPHA Gapor</p>
<p>Nationality: Malaysian</p>
<p>Favourite food: chicks</p>

<br />
<br />

<table class="aboutT">
	<tr>
		<th>Contributions</th>
		<th>Descriptions</th>
	</tr>

	<tr>
		<td>HTML content</td>
		<td>
			<ul>
				<li>write the content of the webpages</li>
				<li>research on idea</li>
				<li>citation of the contents</li>
				<li>design the structure</li>
			</ul>
		</td>
	</tr>
	
	<tr>
		<td>CSS</td>
		<td>
			<ul>
				<li>research for interesting CSS</li>
				<li>decide the main color scheme of the webpages</li>
				<li>give idea of the overall design</li>
				<li>web typography</li>
				<li>visual formatting</li>
				<li>fluid page layout</li>
			</ul>
		</td>
	</tr>

	<tr>
		<td>Validation of HTML</td>
		<td>
			<ul>
				<li>validate html files</li>
				<li>correct the errors</li>
			</ul>
		</td>
	</tr>

	<tr>
		<td>Validation of CSS</td>
		<td>
			<ul>
				<li>validate CSS files</li>
				<li>correct the errors</li>
			</ul>
		</td>
	</tr>

	<tr>
		<td>Validation of XML</td>
		<td>
		<ul>
				<li>validate xml file and correct the errors</li>
				<li>convert html files to xml files</li>
		</ul>
		</td>
	</tr>
</table>
</div>
</article>

<?php include 'include/footer.php';?>

</body>

</html>