<!DOCTYPE html>
<html lang="en">

<head>
	<title>Sarawak | TheBest</title>
	<meta charset="utf-8" />
	<meta name="Author" content="TheBest" />
	<meta name="Description" content="rent,best,house" />
	<meta name="Keywords" content="rent,best,house" />
	<link rel="stylesheet" type="text/css" href="styles/style.css" />
	<script src="script/dropdown.js"></script>
</head>

<body>	
<?php include 'include/header.php';?>
	
	<article class="subareaA">
		<br />
		
		<h1 class="subarea_h1">Sarawak</h1>
		<img class="xsubarea_img" 
		src="https://upload.wikimedia.org/wikipedia/commons/thumb/7/79/Coat_of_arms_of_Sarawak.svg/1200px-Coat_of_arms_of_Sarawak.svg.png" alt="Sarawak" />
		
		<a href="product1.php">
		<div class="subareaC1">
			<img  class="product_img" src="https://a0.muscache.com/im/pictures/42cc81cb-27c4-4648-985a-91d7f2b82f53.jpg?aki_policy=xx_large" alt="The Happiness Home 2">
			<h2>Sweet Home Viva City Megamall Jazz Suites</h2>
		</div>
		</a>
		
		<a href="product2.php">
		<div class="subareaC2">
			<img  class="product_img" src="https://a0.muscache.com/im/pictures/e558f308-dd02-4964-89b5-84b09c602dc4.jpg?aki_policy=xx_large" alt="Cosy Apartments">
			<h2>Cosy Apartment</h2>
		</div>
		</a>
		
		<a href="product3.php">
		<div class="subareaC3">
			<img  class="product_img" src="https://a0.muscache.com/im/pictures/a5dd578b-07fa-4352-a905-ab227094e608.jpg?aki_policy=xx_large" alt="theCHARCOAL">
			<h2>theCHARCOAL</h2>
		</div>
		</a>
		
		<a href="product4.php">
		<div class="subareaC4">
			<img  class="product_img" src="https://a0.muscache.com/im/pictures/3b3ab58a-6c67-44d9-bc78-dde563dfeb3c.jpg?aki_policy=xx_large" alt="Riverbank Suites">
			<h2>Riverbank Suites</h2>
		</div>
		</a>
		
		<a href="product5.php">
		<div class="subareaC5">
			<img  class="product_img" src="https://a0.muscache.com/im/pictures/e74e4296-4f94-4a94-86e2-a9e52050f93a.jpg?aki_policy=xx_large" alt="Boyan Heights Rainforest">
			<h2>Boyan Heights Rainforest</h2>
		</div>
		</a>
		
		<br />
		<br />
		<br />
		<br />
		<br />
		
	</article>
	
	<?php include 'include/footer.php';?>

</body>

</html>