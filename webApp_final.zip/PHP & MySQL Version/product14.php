<!DOCTYPE html>
<html lang="en">

<head>
	<title>The Nordic | TheBest</title>
	<meta charset="utf-8" />
	<meta name="Author" content="TheBest" />
	<meta name="Description" content="rent,best,house" />
	<meta name="Keywords" content="rent,best,house" />
	<link rel="stylesheet" type="text/css" href="styles/style.css" />
	<script src="script/script.js"></script>
	<script src="script/dropdown.js"></script>
</head>

<body>	
<?php include 'include/header.php';?>
	
	<article class="productA">
		<br />
		
		<!--Slideshow implement later-->
		<img class="product_img" src="https://a0.muscache.com/im/pictures/c0125d65-ffdf-495c-b424-9a40911e118e.jpg?aki_policy=x_large" alt="The Nordic" />
		
		<!--Source https://www.airbnb.com/rooms/19001751?location=Pahang%2C%20Malaysia&guests=1&s=jIjczhx1-->
		
		<h1 class="product_h1" id="pTitle">The Nordic</h1>
		
		<aside>
			<form>
				<table>
					<tr class="trow1">
						<th colspan="2">
							RM 149 per night<br/><hr class="line1"/>
						</th>
					</tr>
					
					<tr class="trow2">
						<th colspan="2">
							Date &amp; Guest selection<br/><hr class="line2"/>
						</th>
					</tr>
					
					<tr class="trow3">
						<td>
							Check in
						</td>
						<td>
							<input class="form-ctrl" type="date" name="date"/>
						</td>
					</tr>
					
					<tr class="trow4">
						<td>
							Check out
						</td>
						<td>
							<input class="form-ctrl" type="date" name="date"/>
						</td>
					</tr>
					
					<tr class="trow5">
						<td>
							Guest
						</td>
						<td>
							<select class="form-ctrl" name="guest" size="1">
								<option value="1" selected="selected">1 Guest</option>
								<option value="2">2 Guests</option>
								<option value="3">3 Guests</option>
								<option value="4">4 Guests</option>
								<option value="5">5 Guests</option>
								<option value="6">6 Guests</option>
								<option value="7">7 Guests</option>
								<option value="8">8 Guests</option>
								<option value="9">9 Guests</option>
								<option value="10">10 Guests</option>
							</select>
							
						</td>
					</tr>
					
					<tr class="trow6">
						<td colspan="2">
							<hr class="line3"/><a href="enquiry.php" onclick="nameStore()" class="booknow">Book Now</a>
						</td>
					</tr>
				</table>
			</form>
		</aside>
	
		<table class="specification">
			<tr>
				<td><img class="guest" src="images/icon-guest.svg" alt="Guests bullet"/>5 guests</td>
				<td><img class="bedroom" src="images/bath.png" alt="Bedroom bullet"/>1 bedrooms</td>
				<td><img class="bed" src="images/bed.png" alt="Bed bullet"/>4 beds</td>
				<td><img class="bath" src="images/bath.png" alt="Bathroom bullet"/>2 bathrooms</td>
			</tr>
		</table>
		
		<p class="product_content">LOCATION: Icon City Petaling Jaya. Corner of Federal Highway & LDP. Near Sunway Pyramid & Mid Valley</p>
		
		<h2 class="product_h2">The space</h2>
		<p class="product_content">Welcome to The Nordic</p>
		<p class="product_content">With no regret! Enjoy peaceful and relaxing Scandinavian atmosphere with indoor plants in the comfy home to brighten up your stay. Don’t forget to use our 5 stars facilities too!</p>
		<p class="product_content">This unique and designer spacious duplex can comfortably accommodate up to 5 adults.</p>
		
		<span class="listH">UPPER FLOOR BEDROOM</span>
		
		<ul class="product_content space">
			<li>Entire upper floor just for your bedroom</li>
			<li>KingKoil queen size bed with side tables</li>
			<li>Clean and good quality hotel grade bed sheets and towels</li>
			<li>Remote controlled blackout blinds for privacy & guest who enjoys sleeping in</li>
			<li>Hangers, iron and iron board</li>
			<li>Scandinavian designer armchair with footstool</li>
		</ul>
		
		<span class="listH">LOWER FLOOR BATHROOM</span>
		
		<ul class="product_content space">
			<li>Fully equipped with hair dryer, disposable toothbrush and toothpaste.</li>
			<li>Branded body and hair shampoo</li>
			<li>Panasonic water heater</li>
		</ul>
		
		<span class="listH">LIVING ROOM</span>
		
		<ul class="product_content space">
			<li>3 seater sofa bed</li>
			<li>40” HD LCD TV with solid wood TV cabinet</li>
			<li>Solid wood Scandinavian designer coffee table</li>
			<li>HDMI cable provided to connect your laptop to TV</li>
			<li>Board games available</li>
			<li>Enjoy breathtaking central park view</li>
		</ul>
		
		<span class="listH">KITCHEN</span>
		
		<ul class="product_content space">
			<li>Fully functional kitchen.</li>
			<li>Imported solid wood designer dining table –seats 4 people</li>
			<li>Twinning's tea & coffee provided</li>
			<li>Full utensils, microwave oven, kettle & fridge/freezer.</li>
		</ul>
		
		<h2 class="product_h2">Guest access</h2>		
		<p class="product_content">Located in Icon City, SS8 in Petaling Jaya. Corner of Federal Highway and LDP. You may travel to Sunway Pyramid & Mid Valley Shopping Mall, Bandar Sunway or Subang Jaya within 10mins.</p>
		
		<h2 class="product_h2">Interaction with guests</h2>
		<p class="product_content">We are friendly and reachable easily. Local knowledge like shopping or food guide is just a phone call away. Welcome to contact us anytime!</p>
		
		<h2 class="product_h2">Amenities</h2>
		<ul class="amenities">
			<li>Wifi</li>
			<li>Air conditioning</li>
			<li>Free parking on premises</li>
			<li>Essentials</li>
			<li>TV</li>
			<li>Elevator</li>
			<li>Gym</li>
			<li>Pool</li>
			<li>Kitchen</li>
			<li>Lockbox</li>
			<li>Hair dryer</li>
			<li>Smart lock</li>
		</ul>
		
		<h2 class="product_h2">Location</h2>
		<p class="product_content">The Nordic surrounded by delicious local delicacies, trendy cafes, famous food stalls and iconic shopping malls with less than 10 minutes drive away.</p>
		
		<span class="listH">Distance from Home </span>
		
		<ul class="location">
			<li>10 mins to Sunway Pyramid</li>
			<li>15 mins to Petaling Jaya & Subang Jaya</li>
			<li>20 mins to Pavilion KL, Star Hill, Lot 10</li>
		</ul>
		
		<br />
		
		<p class="product_content">Feel safe to walk around the central park to enjoy windy day with 24 hours friendly & helpful security guard on patrol.</p>
		
		<div class="mapouter">
			<div class="gmap_canvas">
				<iframe id="gmap_canvas" src="https://maps.google.com/maps?q=petaling%20jaya&t=&z=13&ie=UTF8&iwloc=&output=embed"></iframe>
			</div>
		</div>
		
	</article>
	
	<?php include 'include/footer.php';?>

</body>

</html>