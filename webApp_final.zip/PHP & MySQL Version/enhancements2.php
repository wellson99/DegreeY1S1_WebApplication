<!DOCTYPE html>
<html lang="en">

<head>
	<title>Enhancements 2 | TheBest</title>
	<meta charset="utf-8" />
	<meta name="Author" content="TheBest" />
	<meta name="Description" content="rent,best,house" />
	<meta name="Keywords" content="rent,best,house" />
	<link rel="stylesheet" type="text/css" href="styles/style.css" />
	<script src="script/dropdown.js"></script>
</head>

<body>	
<?php include 'include/header.php';?>
	
	<article class="enhancementsA">
		<br />
		
		<h1 class="enhancements_h1">Enhancement 2: JavaScript</h1>
		
		<br />
		
		<section class="enhancementsS">
		<h2 class="enhancements_h2">Smooth Scrolling effect</h2>
		<br />
		<p class="en_con">Smooth scrolling effects are added to the index.php</p>
		<p class="en_con">to enable smooth scrolling for the whole page</p>
		<br />
		<p class="en_con">The effects is done by: </p>
		<p class="en_con">Putting in 5 sections with different class</p>
		<p class="en_con">Putting 5 buttons on the side for user to navigate through different section</p>

		<br />
		
		<p class="en_con">Reference: </p>
		<p class="en_con"><a href="https://codyhouse.co/demo/page-scroll-effects/fixed-hijacking.php">Example of Smooth Scrolling Effect</a></p>
		<br />
		<p class="en_con">This page below has the enhancements:</p>
		
		<ul class="enhancementsL">
			<li><a href="product1.php">index.php</a></li>
		</ul>
		</section>
		
		<section class="enhancementsS">
		<h2 class="enhancements_h2">JavaScript Slideshow</h2>
		<br />
		<p class="en_con">slideshow had enable the visitors skim through the available images without vertical scrolling or unnecessary mouse movements</p>
	
		<br />
		<p class="en_con">Reference: </p>
		<p class="en_con"><a href="https://www.w3schools.com/howto/howto_js_slideshow.asp">W3School Slideshow Example</a></p>
		
		<br />
		
		<p class="en_con">This page below has the enhancements:</p>
		
		<ul class="enhancementsL">			
			<li><a href="about0.php">index.php</a></li>
		</ul>
		</section>
		
	</article>
	
<?php include 'include/footer.php';?>

</body>

</html>