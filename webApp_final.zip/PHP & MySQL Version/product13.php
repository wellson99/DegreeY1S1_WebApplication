<!DOCTYPE html>
<html lang="en">

<head>
	<title>The Scott Garden | TheBest</title>
	<meta charset="utf-8" />
	<meta name="Author" content="TheBest" />
	<meta name="Description" content="rent,best,house" />
	<meta name="Keywords" content="rent,best,house" />
	<link rel="stylesheet" type="text/css" href="styles/style.css" />
	<script src="script/script.js"></script>
	<script src="script/dropdown.js"></script>
</head>

<body>	
<?php include 'include/header.php';?>
	
	<article class="productA">
		<br />
		
		<!--Slideshow implement later-->
		<img class="product_img" src="https://a0.muscache.com/im/pictures/9616e3df-10e7-48fd-b995-e67e86e6bfba.jpg?aki_policy=xx_large" alt="The Scott Garden" />
		
		<!--Source https://www.airbnb.com/rooms/7118389-->
		
		<h1 class="product_h1" id="pTitle">The Scott Garden</h1>
		
		<aside>
			<form>
				<table>
					<tr class="trow1">
						<th colspan="2">
							RM 179 per night<br/><hr class="line1"/>
						</th>
					</tr>
					
					<tr class="trow2">
						<th colspan="2">
							Date &amp; Guest selection<br/><hr class="line2"/>
						</th>
					</tr>
					
					<tr class="trow3">
						<td>
							Check in
						</td>
						<td>
							<input class="form-ctrl" type="date" name="date"/>
						</td>
					</tr>
					
					<tr class="trow4">
						<td>
							Check out
						</td>
						<td>
							<input class="form-ctrl" type="date" name="date"/>
						</td>
					</tr>
					
					<tr class="trow5">
						<td>
							Guest
						</td>
						<td>
							<select class="form-ctrl" name="guest" size="1">
								<option value="1" selected="selected">1 Guest</option>
								<option value="2">2 Guests</option>
								<option value="3">3 Guests</option>
								<option value="4">4 Guests</option>
								<option value="5">5 Guests</option>
								<option value="6">6 Guests</option>
								<option value="7">7 Guests</option>
								<option value="8">8 Guests</option>
								<option value="9">9 Guests</option>
								<option value="10">10 Guests</option>
							</select>
							
						</td>
					</tr>
					
					<tr class="trow6">
						<td colspan="2">
							<hr class="line3"/><a href="enquiry.php" onclick="nameStore()" class="booknow">Book Now</a>
						</td>
					</tr>
				</table>
			</form>
		</aside>
	
		<table class="specification">
			<tr>
				<td><img class="guest" src="images/icon-guest.svg" alt="Guests bullet"/>6 guests</td>
				<td><img class="bedroom" src="images/bath.png" alt="Bedroom bullet"/>1 bedrooms</td>
				<td><img class="bed" src="images/bed.png" alt="Bed bullet"/>4 beds</td>
				<td><img class="bath" src="images/bath.png" alt="Bathroom bullet"/>2 bathrooms</td>
			</tr>
		</table>
		
		<p class="product_content">Located in a prime district along the vibrant Old Klang Road in Kuala Lumpur, it features an exciting inner city lifestyle within easy reach and close proximity to Mid Valley Mall.</p>
		
		<h2 class="product_h2">The space</h2>
		
		<p class="product_content">Welcome to The Scott Garden</p>
		<p class="product_content">The Happiness Home: A home far away from home</p>
		<p class="product_content">The Happiness Home is designed and decorated alike your home sweet home, we aim to maximize your happiness with a homestay experience with us. This fantastic duplex unit design has a large bed room up-stairs and a spacious living hall and kitchen down-stairs. Our furniture are exclusively chosen to fit all the needs for stay from 1 to 6 guests.</p>
		
		<span class="listH">Up-stairs (Bed Room)</span>
		
		<ul class="product_content space">
			<li>1 Queen Size Bed (With Comforter and Pillow) </li>
			<li>1 Single Bed (With Comforter and Pillow)</li>
			<li>1 Floor Single Mattress (With Comforter and Pillow)</li>
			<li>1 Bathroom with water heater </li>
			<li>Air-conditioner</li>
			<li>Hair Dryer </li>
			<li>2 Towels</li>
		</ul>
		
		<span class="listH">Living Room</span>
		
		<ul class="product_content space">
			<li>1 Queen Size Bed </li>
			<li>1 Sofa</li>
			<li>40 “ LED TV</li>
			<li>Air- Conditioner</li>
			<li>High Speed Free Internet WIFI with Hypp TV</li>
		</ul>
		
		<span class="listH">Kitchen</span>
		
		<ul class="product_content space">
			<li>Table for 4 </li>
			<li>Complimentary Coffee and Tea</li>
			<li>Dinning Tools</li>
			<li>Fridge</li>
			<li>Microwave</li>
		</ul>
		
		<h2 class="product_h2">Guest access</h2>		
		<p class="product_content">Guests are able to access to all the facilities on Level 5 with Access Card. Facilities include: Gymnasium, Jogging Track, Infinity Pool, Lush Landscaping with water canals, BBQ pit (require prior booking & security deposit).</p>
		
		<h2 class="product_h2">Interaction with guests</h2>
		<p class="product_content">Your happiness is our main concern, we believe that happiness is contagious. In The Happiness Home, we are not just to offer an accommodation. We love to hear every single happy story from all around the world. We specially design a happiness sharing area at our door entrance, just for you to share your happy stories. Please stay with us, share with us and help make the HOME a happier place to stay.</p>
		<p class="product_content">Please note that this property is independently operated by individual owner. It is a private unit of vacation home and therefore does not have a check in counter. Self Check in arrangement will be advised prior to check in.</p>
		
		<h2 class="product_h2">Amenities</h2>
		<ul class="amenities">
			<li>Wifi</li>
			<li>Air conditioning</li>
			<li>Free parking on premises</li>
			<li>Essentials</li>
			<li>TV</li>
			<li>Elevator</li>
			<li>Gym</li>
			<li>Pool</li>
			<li>Kitchen</li>
			<li>Lockbox</li>
			<li>Hair dryer</li>
		</ul>
		
		<h2 class="product_h2">Location</h2>
		<p class="product_content">The Scott Garden is located in Kuala Lumpur, Wilayah Persekutuan Kuala Lumpur, Malaysia.</p>
		<p class="product_content">Explore yourself to one of KL’s most happening entertainment square and varieties of restaurants just within your walking distance.</p>
		<p class="product_content">KL city is like a food heaven, there are so many restaurants, cafes, eateries and street food everywhere. So do spare a little time to explore around while you stay here.</p>
		
		<br />
		
		<div class="mapouter">
			<div class="gmap_canvas">
				<iframe id="gmap_canvas" src="https://maps.google.com/maps?q=The%20Scott%20Garden&t=&z=13&ie=UTF8&iwloc=&output=embed"></iframe>
			</div>
		</div>
		
	</article>
	
	<?php include 'include/footer.php';?>

</body>

</html>