<!DOCTYPE html>
<html lang="en">

<head>
	<title>PJ New Suite Studio | TheBest</title>
	<meta charset="utf-8" />
	<meta name="Author" content="TheBest" />
	<meta name="Description" content="rent,best,house" />
	<meta name="Keywords" content="rent,best,house" />
	<link rel="stylesheet" type="text/css" href="styles/style.css" />
	<script src="script/script.js"></script>
	<script src="script/dropdown.js"></script>
</head>

<body>	
<?php include 'include/header.php';?>
	
	<article class="productA">
		<br />
		
		<!--Slideshow implement later-->
		<img class="product_img" src="https://a0.muscache.com/im/pictures/8fe015c0-0eb3-437a-8cb4-5e444bb5ab48.jpg?aki_policy=xx_large" alt="PJ New Suite Studio" />
		
		<!--Source https://www.airbnb.com/rooms/8396632?location=Petaling%20Jaya%20Selangor%20Malaysia&adults=1&children=0&infants=0&s=33XBNoT5-->
		
		<h1 class="product_h1" id="pTitle">PJ New Suite Studio</h1>
		
		<aside>
			<form>
				<table>
					<tr class="trow1">
						<th colspan="2">
							RM 149 per night<br/><hr class="line1"/>
						</th>
					</tr>
					
					<tr class="trow2">
						<th colspan="2">
							Date &amp; Guest selection<br/><hr class="line2"/>
						</th>
					</tr>
					
					<tr class="trow3">
						<td>
							Check in
						</td>
						<td>
							<input class="form-ctrl" type="date" name="date"/>
						</td>
					</tr>
					
					<tr class="trow4">
						<td>
							Check out
						</td>
						<td>
							<input class="form-ctrl" type="date" name="date"/>
						</td>
					</tr>
					
					<tr class="trow5">
						<td>
							Guest
						</td>
						<td>
							<select class="form-ctrl" name="guest" size="1">
								<option value="1" selected="selected">1 Guest</option>
								<option value="2">2 Guests</option>
								<option value="3">3 Guests</option>
								<option value="4">4 Guests</option>
								<option value="5">5 Guests</option>
								<option value="6">6 Guests</option>
								<option value="7">7 Guests</option>
								<option value="8">8 Guests</option>
								<option value="9">9 Guests</option>
								<option value="10">10 Guests</option>
							</select>
							
						</td>
					</tr>
					
					<tr class="trow6">
						<td colspan="2">
							<hr class="line3"/><a href="enquiry.php" onclick="nameStore()" class="booknow">Book Now</a>
						</td>
					</tr>
				</table>
			</form>
		</aside>
	
		<table class="specification">
			<tr>
				<td><img class="guest" src="images/icon-guest.svg" alt="Guests bullet"/>3 guests</td>
				<td><img class="bedroom" src="images/bath.png" alt="Bedroom bullet"/>1 bedrooms</td>
				<td><img class="bed" src="images/bed.png" alt="Bed bullet"/>1 beds</td>
				<td><img class="bath" src="images/bath.png" alt="Bathroom bullet"/>1 bathrooms</td>
			</tr>
		</table>
		
		<p class="product_content">Brand New Studio in Petaling Jaya, 30 min from KL City. Fully furnished with WIFI, complete toilet amenities with Sauna & full access to condo facilities –Gym, Jacuzzi, Outdoor Patio, Gazebo, Billiard lounge, 50m lap pool, Karaoke room, BBQ pavilion. Condo is directly linked with a LRT Station, enabling guests to easily commute within the city.</p>
		
		<h2 class="product_h2">The space</h2>
		<p class="product_content">NEW designer studio suite with 1 king sized bed (2pax) and extra mattress ( only upon request) for an extra guest. This non-smoking studio include spacious living area with sofa, LCD TV and 30Mbps Super speed unlimited Wifi access. Basic Kitchenette is also available for light cooking. The whole living area including the bedroom is fully air-conditioned; which we find is important especially for a hot tropical place like Malaysia where the heat can gets to you day and night.</p>
		<p class="product_content">En-suite toilet with shower equipped with relaxing "steam bath" (aka private sauna room) facility is at your disposal. Shower gel, shampoo, clean towels and basic toiletries are provided.</p>
		<p class="product_content">There's an electrical cooker, dining utensils, Iron, ironing board and kettle at the kitchen.</p>
		<p class="product_content">Guests will have access to the premise facilities such as Gym, Jacuzzi, Outdoor Patio, Gazebo, Billiard lounge, BBQ pavilion, 50 Metre Lap Pool, Cascading Pool with water playground for kids, Private Function Room, Karaoke Room.</p>
		<p class="product_content">This fully furnished cozy modern space is a personal home and I welcome travelers, business people, families, friends, couples, from local and abroad.</p>
		
		<h2 class="product_h2">Guest access</h2>		
		<p class="product_content">2 tier tight security with 24-hour security, access card needed to enter the premises, lift access card needed to enter unit level. Parking is available / included with card access at a secured security monitored area within the condo.</p>
		<p class="product_content">Guest may access to all facilities in the building.....<br/>and the whole private studio unit is yours during your stay, YES, the whole studio with privacy assured!</p>
		<p class="product_content">24 Hours Laundry cleaning service, Convenient Store " 7-11, KK Mart, Speedmart 99", food stores are just across the street.</p>
		<p class="product_content">Connectivity<br>Unifi 30Mpbs Fibre broadband wifi is installed. It has great coverage throughout the unit. It has unlimited quota, feel free to download music, stream Netflix, play online games etc. HDMI wire is provided.</p>
		
		<h2 class="product_h2">Interaction with guests</h2>
		<p class="product_content">Am contactable any time through phone calls or you may just drop me a message. I will try to help you in any ways possible. My colleagues and staff are working nearby and they will be able to assist you during my absence (when am out of town).</p>
		
		<h2 class="product_h2">Other things to note</h2>
		<p class="product_content">The space is to accommodate up to 2 people only. You are required to inform me if there is additional guest(s) so that additional foldable sleeping mattress can be provided.</p>
		<p class="product_content">While I am continuously trying to improve the way I host guests, it is very important for you to know I am NOT operating a hotel, hence I DO NOT provide room service. Having said that, I will ensure the place is clean and bedding covers are changed with new ones when you check in. </p>
		<p class="product_content">If you stay more than a night and you need daily housekeeping, I can arrange for a cleaner at an extra cost.</p>
		
		<h2 class="product_h2">Amenities</h2>
		<ul class="amenities">
			<li>Free parking on premises</li>
			<li>Wifi</li>
			<li>Iron</li>
			<li>Kitchen</li>
			<li>Elevator</li>
			<li>Dryer</li>
		</ul>
		
		<h2 class="product_h2">Location</h2>
		
		<div class="mapouter">
			<div class="gmap_canvas">
				<iframe id="gmap_canvas" src="https://maps.google.com/maps?q=PJ%20New%20Suite%20Studio&t=&z=13&ie=UTF8&iwloc=&output=embed"></iframe>
			</div>
		</div>
		
	</article>
	
	<?php include 'include/footer.php';?>

</body>

</html>