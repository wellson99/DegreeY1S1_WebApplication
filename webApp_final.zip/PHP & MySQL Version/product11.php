<!DOCTYPE html>
<html lang="en">

<head>
	<title>DR.SHAZ SUMMER HOUSE | TheBest</title>
	<meta charset="utf-8" />
	<meta name="Author" content="TheBest" />
	<meta name="Description" content="rent,best,house" />
	<meta name="Keywords" content="rent,best,house" />
	<link rel="stylesheet" type="text/css" href="styles/style.css" />
	<script src="script/script.js"></script>
	<script src="script/dropdown.js"></script>
</head>

<body>	
<?php include 'include/header.php';?>
	
	<article class="productA">
		<br />
		<!--Slideshow implement later-->
		<img class="product_img" src="https://a0.muscache.com/im/pictures/bd2db486-17e5-4e96-a99d-8fae2599564f.jpg?aki_policy=xx_large" alt="DR.SHAZ SUMMER HOUSE" />
		
		<!--Source https://www.airbnb.com/rooms/10417226-->
		<h1 class="product_h1" id="pTitle">DR.SHAZ SUMMER HOUSE</h1>
		
		<aside>
			<form>
				<table>
					<tr class="trow1">
						<th colspan="2">
							RM 139 per night<br/><hr class="line1"/>
						</th>
					</tr>
					
					<tr class="trow2">
						<th colspan="2">
							Date &amp; Guest selection<br/><hr class="line2"/>
						</th>
					</tr>
					
					<tr class="trow3">
						<td>
							Check in
						</td>
						<td>
							<input class="form-ctrl" type="date" name="date"/>
						</td>
					</tr>
					
					<tr class="trow4">
						<td>
							Check out
						</td>
						<td>
							<input class="form-ctrl" type="date" name="date"/>
						</td>
					</tr>
					
					<tr class="trow5">
						<td>
							Guest
						</td>
						<td>
							<select class="form-ctrl" name="guest" size="1">
								<option value="1" selected="selected">1 Guest</option>
								<option value="2">2 Guests</option>
								<option value="3">3 Guests</option>
								<option value="4">4 Guests</option>
								<option value="5">5 Guests</option>
								<option value="6">6 Guests</option>
								<option value="7">7 Guests</option>
								<option value="8">8 Guests</option>
								<option value="9">9 Guests</option>
								<option value="10">10 Guests</option>
							</select>
							
						</td>
					</tr>
					
					<tr class="trow6">
						<td colspan="2">
							<hr class="line3"/><a href="enquiry.php" onclick="nameStore()" class="booknow">Book Now</a>
						</td>
					</tr>
				</table>
			</form>
		</aside>
	
		<table class="specification">
			<tr>
				<td><img class="guest" src="images/icon-guest.svg" alt="Guests bullet"/>16+ guests</td>
				<td><img class="bedroom" src="images/bath.png" alt="Bedroom bullet"/>4 bedrooms</td>
				<td><img class="bed" src="images/bed.png" alt="Bed bullet"/>15 beds</td>
				<td><img class="bath" src="images/bath.png" alt="Bathroom bullet"/>4 bathrooms</td>
			</tr>
		</table>
		
		<p class="product_content">
		Enjoy this EXCLUSIVE accommodation at an affordable price with your loved ones. Situated 23 mins from KL Airport & KLCC, five mins from Bangi Train Station & PLUS Highway Exit, this house offered you the best of urban living thus promises you a perfect summer vacation for family & friends.
		</p>
		
		<h2 class="product_h2">The space</h2>
		
		<p class="product_content">Welcome to DR SHAZ SUMMER HOUSE @ BANGI, MALAYSIA</p>
		<p class="product_content">Minimum bookings for FRIDAYS AND SATURDAYS are TWO nights, and the rate is displayed. Kindly prompt us if you decide to book for one night; tagged at RM375/night including complimentary breakfast for eight pax for ONE night only.
		</p>
		
		<h2 class="product_h2">Guest access</h2>		
		<p class="product_content">You can have access to the local playgrounds and jog track.</p>
		<p class="product_content">The hypermarket, surau, food outlets and retails store are only walking distance.
		</p>
		<p class="product_content">Other amenities like petrol pump, bank, gym, Mamak's stall are only 5 mins drive.
		</p>
		
		<h2 class="product_h2">Interaction with guests</h2>
		<p class="product_content">Kindly inform us once you arrived. Ms Kay , my house supervisor will welcome you shortly and ensure that you will be briefed about the place.
		</p>
		
		<h2 class="product_h2">Amenities</h2>
		<ul class="amenities">
			<li>Air conditionning</li>
			<li>Free parking</li>
			<li>Breakfast</li>
			<li>Essentials</li>
			<li>TV</li>
			<li>Private entrance</li>
		</ul>
		
		<h2 class="product_h2">Location</h2>
		<p class="product_content">The neighborhood is a New Township in the matured townships of Southern Kuala Lumpur and it is nearby other elite townships in Bangi, Nilai and Kajang. The community is of Malaysian families with the majority Muslim background.
		</p>
		<span class="listH">Nearby Townships/Cities</span>
		<ul class="location">
			<li>Bandar Seri Putra 3.5km</li>
			<li>Bandar Bukit Mahkota 3.5km</li>
			<li>Bangi Lama 1.7km</li>
			<li>Nilai 37km</li>
			<li>Kajang 16km</li>
			<li>Pajam 11km</li>
			<li>Putrajaya 18km</li>
			<li>Cyberjaya 21km</li>
			<li>KLCC 25km</li>
		</ul>
		
		<br />
		
		<p class="product_content">We do collaborate with local car rentals and van rentals for daily basis. We have a variety of cars ranges from $20 to $50 dollar per day depending on the type of cars and day of rentals.</p>
		
		<div class="mapouter">
			<div class="gmap_canvas">
				<iframe id="gmap_canvas" src="https://maps.google.com/maps?q=%20DR.SHAZ%20SUMMER%20HOUSE&t=&z=13&ie=UTF8&iwloc=&output=embed"></iframe>
			</div>
		</div>
		
	</article>
	
<?php include 'include/footer.php';?>

</body>

</html>